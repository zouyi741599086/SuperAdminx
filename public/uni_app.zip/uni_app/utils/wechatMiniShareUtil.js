import util from './util.js';
import {
	useUserStore
} from '@/store/user';

// 添加状态变量
let isInitialized = false;
let initPromise = null;
// 默认分享配置变量
let defaultShareConfig = {};

/**
 * 微信小程序分享工具
 * App.vue 里面引入，并增加onShareAppMessage 跟 onShareTimeline 方法
 * 然后每个页面都调用如下
 * onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage();
	}) 
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline();
	})
 */
export default {
	/**
	 * 初始化微信配置和分享配置
	 */
	initConfig() {
		// 如果正在初始化，返回相同的 Promise
		if (initPromise) {
			return initPromise;
		}

		// 如果已经初始化，返回已完成的 Promise
		if (isInitialized) {
			return Promise.resolve();
		}

		// 创建初始化 Promise
		initPromise = new Promise((resolve, reject) => {
			// 并行获取微信配置和分享配置
			Promise.all([
				util.getConfig('share_mini_config')
			]).then(([shareConfigRes]) => {
				// 保存分享配置
				defaultShareConfig = shareConfigRes || {};
				isInitialized = true;
				resolve();

			}).catch(error => {
				reject(error);
			});
		});

		return initPromise;
	},

	/**
	 * 分享微信
	 * @param {object} _shareConfig
	 *  - title 标题
	 *  - path 路劲，如 pages/news/info/index 会自动带上当前页面参数 及 用户的推广id
	 *  - img 图片
	 */
	async onShareAppMessage(_shareConfig = {}) {
		// 如果未初始化，先初始化
		if (!isInitialized) {
			await this.initConfig();
		}
		
		if (_shareConfig.title) {
			_shareConfig.title = `${_shareConfig.title}-${defaultShareConfig.share_title}`;
		}

		// 优先使用传入的参数，其次使用配置中的默认值
		const shareTitle = _shareConfig.title || defaultShareConfig.share_title || '';
		const sharePath = this.getCurrentPageUrlWithArgs('url', _shareConfig.path);
		const shareImg = _shareConfig.img || defaultShareConfig.share_img || '';
		
		return {
			title: shareTitle,
			path: sharePath,
			imageUrl: shareImg,
		}
	},

	/**
	 * 分享朋友圈
	 * @param {object} _shareConfig
	 *  - title 标题
	 *  - img 图片
	 */
	async onShareTimeline(_shareConfig = {}) {
		// 如果未初始化，先初始化
		if (!isInitialized) {
			await this.initConfig();
		}
		
		if (_shareConfig.title) {
			_shareConfig.title = `${_shareConfig.title}-${defaultShareConfig.share_title}`;
		}

		// 优先使用传入的参数，其次使用配置中的默认值
		const shareTitle = _shareConfig.title || defaultShareConfig.share_title || '';
		const shareQuery = this.getCurrentPageUrlWithArgs('query');
		const shareImg = _shareConfig.img || defaultShareConfig.share_img || '';

		return {
			title: shareTitle,
			query: shareQuery,
			imageUrl: shareImg,
		}
	},

	/**
	 * 获取当前页面信息
	 * @param {string} type 
	 * url》完整的url包括路劲+参数+推广用户id，如 /pages/goodsInfo/index?id=1&invite_code=from_id_123
	 * path》路劲 如 /pages/goodsInfo/index
	 * query》参数+推广用户id 如 id=1&invite_code=from_id_123
	 * @param {string} 自带path, 如 pages/index/index
	 */
	getCurrentPageUrlWithArgs(type = 'url', path = null) {
		const pages = getCurrentPages()
		const currentPage = pages[pages.length - 1]
		// 获取当前页面的路由（不带斜杠）
		const route = path || currentPage.route

		if (type == 'path') {
			return `/${route}`;
		}

		// 获取当前页面的参数
		const options = currentPage.options

		const user = useUserStore();
		options.invite_code = user.data.id ? `from_id_${user.data.id}` : '';

		// 构建查询参数字符串
		const queryString = Object.keys(options)
			.map(key => `${key}=${encodeURIComponent(options[key])}`)
			.join('&')

		if (type == 'query') {
			return queryString;
		}

		// 返回完整路径
		return `/${route}${queryString ? '?' + queryString : ''}`
	}
}