// 安卓需要申请的权限
export default {
	"WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,READ_MEDIA_IMAGES": {
		name: "存储", // 当前权限的名称
		explain: "上传头像完善个人信息" // 权限说明
	},
	"CAMERA": {
		name: "相机", // 当前权限的名称
		explain: "上传头像完善个人信息" // 权限说
	}
}