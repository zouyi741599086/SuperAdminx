import {
    ref,
    onUnmounted,
    computed,
    watch
} from 'vue'

/**
 * Uniapp 竞态条件安全列表请求 Hook
 */
export function useRaceSafeList(options = {}) {
    const {
        api,
        params: initialParams = {},
        autoLoad = true,
        pageSize = 20,
        autoRefreshOnParamsChange = true,
        transformResponse = null, // 新增：数据转换函数
        transformItem = null // 新增：单个数据项转换函数
    } = options

    // 响应式数据
    const list = ref([])
    const loading = ref(false)
    const loadingStatus = ref('loading') // loading | noMore | nodata | error
    const pageInfo = ref({
        page: 1,
        pageSize: pageSize,
        total: 0,
        totalPage: 0
    })

    // 使用响应式参数，以便可以监听变化
    const params = ref({
        ...initialParams
    })

    // 计算属性：参数签名，用于监听参数变化
    const paramsSignature = computed(() => {
        // 创建一个稳定的参数签名，排除 page 参数（因为分页变化不应该触发自动刷新）
        const {
            page,
            ...restParams
        } = params.value
        return JSON.stringify(Object.keys(restParams)
            .sort()
            .map(key => ({
                key,
                value: restParams[key]
            })))
    })

    // 实例私有状态 - 每个 Hook 实例完全独立
    const instanceState = ref({
        currentRequestId: 0,
        isRequestPending: false
    })

    /**
     * 处理数据转换
     */
    const processData = (data) => {
        let processedData = data
        
        // 如果提供了 transformResponse 函数，对整个响应进行处理
        if (typeof transformResponse === 'function') {
            processedData = transformResponse(processedData)
        }
        
        // 如果提供了 transformItem 函数，对每个数据项进行处理
        if (typeof transformItem === 'function' && Array.isArray(processedData?.data)) {
            processedData.data = processedData.data.map(item => transformItem(item))
        }
        
        return processedData
    }

    /**
     * 标记当前实例的所有请求为过期
     */
    const cancelCurrentRequests = () => {
        instanceState.value.currentRequestId++
        instanceState.value.isRequestPending = false
    }

    /**
     * 执行安全的列表请求
     */
    const executeSafeRequest = async (isLoadMore = false) => {
        // 生成当前请求的唯一ID
        const requestId = ++instanceState.value.currentRequestId
        instanceState.value.isRequestPending = true

        loading.value = true
        loadingStatus.value = 'loading'

        try {
            // 准备请求参数（排除 page 和 pageSize 以外的参数）
            const {
                page: _,
                pageSize: __,
                ...requestParams
            } = params.value

            const finalParams = {
                ...requestParams,
                page: isLoadMore ? pageInfo.value.page + 1 : 1,
                pageSize: pageInfo.value.pageSize
            }

            // 执行 API 请求
            const res = await api(finalParams)

            // 关键检查：如果这不是最新的请求，忽略响应
            if (requestId !== instanceState.value.currentRequestId) {
                return
            }

            // 处理成功响应
            if (res.code === 1) {
                // 处理数据转换
                const processedData = processData(res.data || {})
                const data = processedData || {}

                // 更新分页信息
                pageInfo.value.total = data.total || 0
                pageInfo.value.totalPage = data.last_page || Math.ceil((data.total || 0) / pageInfo.value.pageSize)

                // 处理列表数据
                if (!isLoadMore) {
                    // 刷新操作
                    pageInfo.value.page = 1
                    list.value = data.data || []
                } else {
                    // 加载更多
                    pageInfo.value.page += 1
                    list.value = [...list.value, ...(data.data || [])]
                }

                // 更新加载状态
                updateLoadingStatus(data.data || [])
            } else {
                // API 返回错误码
                loadingStatus.value = 'error'
            }
        } catch (error) {
            // 只有当前请求是最新请求时才处理错误
            if (requestId === instanceState.value.currentRequestId) {
                loadingStatus.value = 'error'
            }
        } finally {
            // 只有当前请求是最新请求时才更新加载状态
            if (requestId === instanceState.value.currentRequestId) {
                loading.value = false
                instanceState.value.isRequestPending = false
            }
        }
    }

    /**
     * 更新加载状态
     */
    const updateLoadingStatus = (data) => {
        if (!data || data.length === 0) {
            loadingStatus.value = pageInfo.value.page === 1 ? 'nodata' : 'noMore'
        } else if (data.length < pageInfo.value.pageSize) {
            loadingStatus.value = 'noMore'
        } else {
            loadingStatus.value = 'other'
        }
    }

    /**
     * 刷新列表（第一页）
     */
    const refresh = async () => {
        cancelCurrentRequests() // 取消之前的请求
        await executeSafeRequest(false)
    }

    /**
     * 加载更多
     */
    const loadMore = async () => {
        if (loadingStatus.value === 'noMore' || loading.value) {
            return
        }
        await executeSafeRequest(true)
    }

    /**
     * 更新参数并刷新（用于筛选条件变化）
     */
    const updateParams = (newParams, autoRefresh = true) => {
        // 合并参数
        params.value = {
            ...params.value,
            ...newParams
        }

        // 如果需要自动刷新
        if (autoRefresh) {
            // 这里不需要手动调用 refresh，因为 watch 会自动检测到参数变化
            // 但我们确保 page 重置为 1
            pageInfo.value.page = 1
        }
    }

    /**
     * 重置为初始状态
     */
    const reset = () => {
        cancelCurrentRequests()
        params.value = {
            ...initialParams
        }
        list.value = []
        pageInfo.value.page = 1
        loadingStatus.value = 'loading'
        loading.value = false
    }

    /**
     * 清理函数 - 组件卸载时调用
     */
    const cleanup = () => {
        cancelCurrentRequests()
    }

    // 监听参数变化，自动刷新
    if (autoRefreshOnParamsChange) {
        watch(
            paramsSignature,
            (newVal, oldVal) => {
                // 参数签名发生变化时，自动刷新（排除首次加载）
                if (oldVal !== undefined && newVal !== oldVal) {
                    refresh()
                }
            }, {
                // 立即触发，以便在初始参数变化时也能捕获
                immediate: false, // 设置为 false，避免初始加载时重复触发
            }
        )
    }

    // 自动加载初始数据
    if (autoLoad) {
        setTimeout(() => {
            refresh()
        }, 0)
    }

    // 注册卸载清理
    onUnmounted(() => {
        cleanup()
    })

    return {
        // 数据
        list, // 列表数据
        loading, // 是否正在请求中
        loadingStatus, // 数据状态（包括 loading、noMore、nodata、error、other）
        pageInfo, // 分页信息，包括当前页码、每页大小、总条数、总页数
        params, // 当前请求参数（响应式，可被外部访问和修改，修改后会根据配置决定是否自动刷新）

        // 方法
        refresh, // 刷新函数，重新加载第一页
        loadMore, // 加载更多函数，加载下一页
        updateParams, // 更新参数并回到第一页（可设置是否自动刷新）
        reset, // 重置函数，将参数重置为初始状态，并清空列表，回到第一页
        cleanup, // 清理函数，用于组件卸载时取消未完成的请求
    }
}