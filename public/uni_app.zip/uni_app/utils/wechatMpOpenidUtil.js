import {
	wechatMpApi
} from '@/utils/api/wechatMp.js';

/**
 * 微信公众号获取openid
 * appShow的时候判断是微信浏览器的时候，在判断本地是否有存weixin_mp_openid
 * 没得openid的话，调用接口获取授权url，然后跳转到腾讯的url获取code，在返回来获取code到后台去换openid
 */
export default {
	/**
	 * 初始化微信配置和分享配置
	 */
	init() {
		// 如果本地已经有weixin_mp_openid 了
		if (uni.getStorageSync('weixin_mp_openid')) {
			return;
		}
		
		// 第一步，获取code来换openid
		const code = this.getUrlCode();
		if (!code) {
			uni.setStorageSync('openid_front_url', window.location.href);
			wechatMpApi.getOauthRedirectUrl({
				url: window.location.href
			}).then(res => {
				window.location.href = res.data;
			});
			return;
		}

		// 第二步，用code换openid
		wechatMpApi.getUserByCode({
			code: code
		}).then(res => {
			uni.setStorageSync('weixin_mp_openid', res.data.openid);
			uni.setStorageSync('weixin_unionid', res.data.unionid);
			
			// 获取完后跳回获取openid前的页面
			const openid_front_url = uni.getStorageSync('openid_front_url');
			uni.removeStorageSync('openid_front_url');
			window.location.href = openid_front_url;
		});

	},

	// 从url上获取code参数的内容
	getUrlCode() {
		let result;
		const url = window.location.href;
		// 1. 先判断是否包含问号，如果没有问号则直接返回false
		const questionMarkIndex = url.indexOf('?');
		if (questionMarkIndex === -1) {
			return result; // 没有问号，没有参数
		}

		// 2. 截取问号后面的部分
		const queryString = url.substring(questionMarkIndex + 1);
		if (!queryString) {
			return result; // 问号后面没有内容
		}

		// 3. 分割成数组（先按&分割参数，再按=分割键值）
		queryString.split('&').forEach(param => {
			const [key, value] = param.split('=');
			if (key == 'code') {
				result = value;
			}
		});

		return result;
	}
}