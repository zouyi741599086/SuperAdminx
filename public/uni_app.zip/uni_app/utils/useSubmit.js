// hooks/useSubmit.js
import {
	ref
} from 'vue'

/**
 * 表单提交钩子
 * @param {boolean} successResetStatus 提交成功后是否重置状态
 */
export function useSubmit(successResetStatus = false) {
	const submitting = ref(false)

	const handleSubmit = (submitFn) => {
		if (submitting.value) return;

		submitting.value = true;

		// 执行提交函数
		submitFn().then(res => {
			if (res.code !== 1) {
				submitting.value = false;
			}
			if (res.code == 1 && successResetStatus) {
				submitting.value = false;
			}
		}).catch(res => {
			submitting.value = false;
		})
	}

	return {
		submitting,
		handleSubmit
	}
}