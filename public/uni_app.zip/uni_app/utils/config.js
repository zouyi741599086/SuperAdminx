

export default {
	name: "Shop", // 应用名称
	devBaseURL: 'http://192.168.1.192:8888', // 开发环境请求地址
	baseURL: 'https://shop.superadminx.com', // 正式环境请求地址
	devStaticURL: '/static/img', // 开发环境 静态资源所在地址
	staticURL: '/static/img', // 正式环境 静态资源所在地址
	// rsa加密公钥
	rsaPublic:  `-----BEGIN PUBLIC KEY-----
    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtRjX81sJAu8pyN4IQyXo
    9WE5GYevieBcTiDhGTknKCGMH3sOrdFkj5RwNFzsH5cy//5Otutj4rarHebv5CUo
    XfyBlDwCeyO1ampnZPUEJP50XW54eER5+NH+BFlGxMJJRhuWe9RXRmjdI6iq5trD
    Clr2MrAvFY1e8whjPSka9KXDOdK68bH52goy0bWwDBPWS+8p+f3Le9j82L9sdz2A
    cyoBkwMykgAV80QuE5TTFAwk3ERZf0Koj4QJMYrAEz3qc3B7mAVtbWjUWW7/EhnU
    i2NbsBkUh/n6ftxT86X+g7+nBDSCKGJ+o2z/e3cEc1GZa6pyNUYEt2dsaYad+0vf
    NwIDAQAB
    -----END PUBLIC KEY-----`,
};