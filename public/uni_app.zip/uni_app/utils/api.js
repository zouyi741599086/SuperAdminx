//import * as cryptoJs from '@/utils/cryptoJs.js';

import cryptoJs from './crypto.js'
import util from './util.js'
import config from './config.js';
import {
	useUserStore
} from '@/store/user.js';
import {
	useBalanceStore
} from '@/store/balance.js';

let baseURL = config.baseURL;
let encryptData = true;

//开发环境的时候
if (process.env.NODE_ENV === 'development') {
	baseURL = config.devBaseURL;
	encryptData = false;
}

const getUrl = (url) => {
	if (url.indexOf('://') == -1) {
		url = baseURL + url.trim();
	}
	return url;
};

const getHeader = (aes_key, aes_iv) => {
	let header = {
		'SuperAdminxKeySecret': cryptoJs.rsaEncrypt(aes_key + aes_iv),
		// X-Client-Type不能乱改，需要同时改登录api、jwt配置、登录页、登录api
		// #ifdef MP-WEIXIN
		'X-Client-Type': 'weixin-mini',
		// #endif
		// #ifdef APP
		'X-Client-Type': 'app',
		// #endif
		// #ifdef H5 || WEB
		'X-Client-Type': 'h5',
		// #endif
	};
	try {
		let token = uni.getStorageSync('token');
		if (token) {
			header.token = cryptoJs.rsaEncrypt({
				token,
				time: new Date().getTime()
			});
		}
	} catch (e) {
		//console.log(e)
	}
	return header;
};

/**
 * 发起请求
 * @param {String} url 请求的参数
 * @param {Object} params 请求的参数
 * @param {Boolean|String} showLoading 是否显示loading，或者传loading里面的文字
 * @param {Boolean} showError 错误的时候是否弹窗提示错误信息
 * @param {Boolean} errDelStorage 非法请求的时候是否清空登录并跳转首页
 */
const http = ({
	url,
	params = {},
	showLoading,
	showError,
	errDelStorage,
	...other
} = {}) => {
	// 弹窗加载中
	if (showLoading !== false) {
		uni.showLoading({
			title: typeof showLoading == 'string' ? showLoading : '',
			mask: true
		});
	}

	const aes_key = util.getStr(32);
	const aes_iv = util.getStr(16);
	return new Promise((resolve, reject) => {
		uni.request({
			url: getUrl(url),
			data: encryptData ? {
				encrypt_data: cryptoJs.aesEncrypt(params, aes_key, aes_iv)
			} : params,
			header: {
				...getHeader(aes_key, aes_iv),
				'content-type': 'application/json'
			},
			...other,
			complete: (res) => {
				// 关闭加载弹窗
				if (showLoading !== false) {
					uni.hideLoading();
				}
				// 先判断 res.data 是否存在
				if (!res.data) {
					if (showError === true) {
						util.toast('网络错误或服务器无响应')
					}
					reject(res);
					return;
				}
				// 弹出错误
				if (showError === true && res.data.code != 1) {
					util.toast(res.data?.message || '网络错误')
				}
				if (res.statusCode >= 200 && res.statusCode < 300) {
					// 数据解密
					if (encryptData === true && res.data.encrypt_data) {
						res.data.data = cryptoJs.aesDecrypt(res.data.encrypt_data, aes_key,
							aes_iv);
					}
					// 非法请求 强制清除登录并跳转
					if (errDelStorage === true && res.data?.code == -2) {
						uni.removeStorageSync('token');
						const user = useUserStore();
						user.data = {};
						const balance = useBalanceStore();
						balance.data = {};
						util.toPages('/pages/index/index');
					}
					if (res.data?.code == 1) {
						resolve(res.data);
					} else {
						reject(res.data);
					}
				} else {
					reject(res);
				}
			}
		});
	});
};

export default {
	get(url, params = {}, showLoading = false, showError = false, errDelStorage = true) {
		return http({
			url,
			params,
			showLoading,
			showError,
			errDelStorage,
			method: 'get'
		});
	},
	post(url, params = {}, showLoading = false, showError = false, errDelStorage = true) {
		return http({
			url,
			params,
			showLoading,
			showError,
			errDelStorage,
			method: 'post'
		});
	},
	put(url, params = {}, showLoading = false, showError = false, errDelStorage = true) {
		return http({
			url,
			params,
			showLoading,
			showError,
			errDelStorage,
			method: 'put'
		});
	},
	myDelete(url, params = {}, showLoading = false, showError = false, errDelStorage = true) {
		return http({
			url,
			params,
			showLoading,
			showError,
			errDelStorage,
			method: 'delete'
		});
	},
	upload(url, filePath, name, params = {}, showLoading = false) {
		return new Promise((resolve, reject) => {
			// 弹窗加载中
			if (showLoading !== false) {
				uni.showLoading({
					title: typeof show == 'string' ? show : '',
					mask: true
				});
			}
			const aes_key = util.getStr(32);
			const aes_iv = util.getStr(16);
			uni.uploadFile({
				url: getUrl(url),
				filePath: filePath,
				name: name,
				formData: params,
				header: getHeader(aes_key, aes_iv),
				complete: (res) => {
					if (showLoading !== false) {
						uni.hideLoading();
					}
					if (res.statusCode >= 200 && res.statusCode < 300) {
						const result = JSON.parse(res.data);
						if (result.code === 1) {
							resolve(result);
						} else {
							util.toast(result.message || '网络错误')
							reject(result);
						}
					} else {
						reject(res);
					}
				}
			});
		});
	},
	getHeader
};