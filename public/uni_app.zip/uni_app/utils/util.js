import config from './config.js';
import api from './api.js';
import {
	useUserStore
} from '@/store/user';
import pages from '../pages.json';
import {
	configApi
} from './api/config.js';

export default {
	/**
	 * 节流
	 */
	debounce(fn, wait = 500) {
		let timerId;
		return function(...args) {
			clearTimeout(timerId);
			timerId = setTimeout(() => {
				fn.apply(this, args);
			}, wait);
		};
	},

	/**
	 * 防抖
	 */
	throttle(fn, wait = 500) {
		let timerId;
		return function(...args) {
			if (timerId) return;
			timerId = setTimeout(() => {
				fn.apply(this, args);
				timerId = null;
			}, wait);
		};
	},

	/**
	 * 验证手机号格式
	 * @param {string} tel 手机号
	 * @return {boolean}
	 */
	checkTel(tel) {
		if (!tel) {
			return false;
		}
		tel = tel.trim();
		if (/^1[3|4|5|6|7|8|9]\d{9}$/.test(tel)) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 获取随机字符串
	 * @param {Number} number 字符串的长度 
	 * @param {letter} boolean 是否包含字母
	 * @returns 
	 */
	getStr(number, letter = true) {
		let x = '0123456789';
		if (letter) {
			x += 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz';
		}
		let str = ''
		for (let i = 0; i < number; i++) {
			str += x[parseInt(Math.random() * x.length)]
		}
		return str
	},

	/**
	 * 预览图片或视频，如果是小程序可以预览图片跟视频，非小程序只能预览图片
	 * @param {string || number} url 当前预览的连接，或者是在list中的索引
	 * @param {array} list 需要预览的资源的列表
	 */
	previewImg(url, list) {
		// #ifdef MP
		//先过滤找出图片的连接
		let regs = /\.(jpg|jpeg|png|gif|webp)$/i;
		let urls = list.map(item => {
			return {
				url: item,
				// type: regs.test(item) ? 'image' : 'video'
				type: 'image'
			}
		});
		wx.previewMedia({
			current: typeof url == 'number' ? url : list.indexOf(url),
			sources: urls
		})
		// #endif

		//非微信小程序的时候编译
		// #ifndef MP-WEIXIN
		//先过滤找出图片的连接
		let regs = /\.(jpg|jpeg|png|gif|webp)$/i;
		let urls = list.filter(item => regs.test(item));
		if (urls) {
			uni.previewImage({
				current: typeof url == 'number' ? url : list.indexOf(url),
				urls,
			});
		}
		// #endif
	},

	/**
	 * 页面跳转
	 * @param string url 跳转的页面
	 * @param boolean close true》关闭当前页面跳转，all》关闭所有页面进行跳转
	 * @param boolean isLogin 是否需要登录后才能跳转
	 */
	toPages(url, close = false, isLogin = false) {
		// 是否需要检测登录
		if (isLogin) {
			const user = useUserStore();
			if (!user.data?.id) {
				this.isLogin(2);
				return; // 停止后续执行
			}
		}
		if (!url || url == '') {
			return false;
		}

		// 判断是否是tabBar 主页面
		if (pages?.tabBar?.list?.some(item => `/${item.pagePath}` == url)) {
			uni.switchTab({
				url
			});
			return;
		}
		if (close == true) {
			uni.redirectTo({
				url
			});
		} else if (close == 'all') {
			uni.reLaunch({
				url
			});
		} else {
			uni.navigateTo({
				url
			});
		}
	},

	/**
	 * 返回上一页
	 * @param Int delta 返回的页面
	 */
	backPage(delta = 1) {
		const routes = getCurrentPages();
		//比如返回1页，如果路由栈里面只要1页，说明没得上1页就只能返回首页，如果返回2页，路由栈里面只有2页，说明只能返回上一页无法返回上2页
		if (routes.length == delta) {
			return uni.switchTab({
				url: '/pages/index/index'
			});
		}
		uni.navigateBack({
			delta,
		})

	},

	/**
	 * modal弹窗选择确认
	 * @param {string || object} params
	 */
	modal(params = {}) {
		if (typeof params === 'string') {
			params = {
				content: params
			};
		}
		return new Promise((resolve) => {
			let _params = Object.assign({
				title: '提示',
				content: '',
				confirmColor: '#DC2E23',
			}, params);

			_params.success = res => {
				if (res.confirm) {
					resolve();
				}
			};
			uni.showModal(_params);
		});
	},

	/**
	 * 弹窗提示
	 * @param {string || object} 参数 或直接 弹窗内容
	 * @param {string} 类型，auto》自动判断用toast还是modal，toast》强制toast弹窗，modal》强制modal弹窗
	 */
	toast: (params = {}, type = 'auto') => {
		if (typeof params === 'string') {
			params = {
				message: params
			};
		}
		if (type == 'auto') {
			type = params.message.length < 12 ? 'toast' : 'modal';
		}
		if (type == 'toast') {
			uni.showToast({
				title: params.message,
				icon: 'none',
				duration: 2500
			});
		}
		if (type == 'modal') {
			uni.showModal({
				title: params.title || '提示',
				showCancel: false,
				content: params.message,
				confirmColor: '#DC2E23',
			});
		}
		return;
	},
	/**
	 * 检测登录
	 * @param {int} type 1》未登录直接跳转到登录页，2》弹窗提示是否登录
	 * @param {boolean} close 未登录的时候是否关闭当前页面跳转到登录页
	 * @return boolean 已登录返回true
	 */
	isLogin(type = 0, close = false) {
		const user = useUserStore();
		if (!user.data?.id) {
			if (type == 1) {
				this.toPages('/pages/login/index', close);
			}
			if (type == 2) {
				this.modal({
					title: '提示',
					content: '未登录，是否现在去登录~',
					confirmText: '去登录',
					cancelText: '取消'
				}).then(res => {
					this.toPages('/pages/login/index', close);
				})
			}
			return false;
		}
		return true;
	},
	/**
	 * 获取配置
	 * @param {String} name 配置名称
	 */
	getConfig(name) {
		return configApi.getConfig({
			name
		}).then(res => {
			return res.data;
		})
	},

	// 判断是否是微信浏览器
	isWeChatBrowser() {
		try {
			const target = navigator.userAgent.toLowerCase();
			return /micromessenger/.test(target);
		} catch {
			return false;
		}
	},

	/**
	 * 检测上传只能是图片
	 * @param {Object} file 文件名称或文件路劲
	 */
	isUploadFile(file) {
		const suffix = file.split('.').pop();
		return ['png','jpg','jpeg'].includes(suffix);
	}

}