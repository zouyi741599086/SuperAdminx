import util from './util.js';
import wechatMiniShareUtil from './wechatMiniShareUtil.js';

export default {
	// #ifdef MP || APP
	/**
	 * 保存图片到相册，小程序跟app能使用
	 * @param {Object} filePath 文件地址（支持网络地址和本地地址）
	 */
	async saveAlbum(filePath) {
		try {
			// 如果是网络图片，先下载到本地
			const localPath = await this._downloadImageIfNeeded(filePath);
			
			uni.saveImageToPhotosAlbum({
				filePath: localPath,
				success: (res) => {
					util.toast('保存成功');
				},
				fail: (err) => {
					if (err.errMsg == 'saveImageToPhotosAlbum:fail auth deny') {
						// #ifdef MP
						uni.getSetting({
							success: (res) => {
								if (res.authSetting['scope.writePhotosAlbum'] === false) {
									// 用户已拒绝授权，提示用户授权
									this.promptAuthorization();
								}
							}
						})
						// #endif
					} else {
						util.toast('保存失败');
					}
				}
			});
		} catch (err) {
			util.toast('图片处理失败');
		}
	},
	// #endif

	// #ifdef MP
	/**
	 * 分享海报，微信小程序能使用
	 * @param {Object} path 图片地址（支持网络地址和本地地址）
	 * @param {String} pagePath 从消息小程序入口打开小程序的路径，如 pages/index/index，不传默认当前页
	 */
	async shareImg(path, pagePath = null) {
		try {
			// 如果是网络图片，先下载到本地
			const localPath = await this._downloadImageIfNeeded(path);
			
			const entrancePath = wechatMiniShareUtil.getCurrentPageUrlWithArgs('url', pagePath);
			wx.showShareImageMenu({
				path: localPath, // 要分享的图片地址
				needShowEntrance: true, // 分享的图片消息是否要带小程序入口 (仅部分小程序类目可用)
				entrancePath: entrancePath, // 从消息小程序入口打开小程序的路径，如果当前页面允许分享给朋友，则默认为当前页面路径，否则默认为小程序首页
				success: (res) => {
					// 分享成功处理
				},
				fail: (err) => {
					if (err.errMsg === 'showShareImageMenu:fail auth deny') {
						uni.getSetting({
							success: (res) => {
								if (res.authSetting['scope.writePhotosAlbum'] === false) {
									// 用户已拒绝授权，提示用户授权
									this.promptAuthorization();
								}
							}
						})
					}
				},
			});
		} catch (err) {
			util.toast('图片处理失败');
		}
	},
	// #endif

	// #ifdef MP
	// 提示授权
	promptAuthorization() {
		util.modal('您未授权保存图片到相册，是否前往设置页面进行授权？').then(res => {
			uni.openSetting({
				success: function(res) {
					if (res.authSetting['scope.writePhotosAlbum']) {
						util.modal('授权成功，请重新点击保存');
					}
				},
			})
		})
	},
	// #endif
	
	/**
	 * 私有方法：下载图片到本地（如果是网络图片）
	 * @param {String} imagePath 图片路径
	 * @returns {Promise<String>} 本地图片路径
	 */
	async _downloadImageIfNeeded(imagePath) {
		// 如果不是网络图片，直接返回原路径
		if (!imagePath.startsWith('http://') && !imagePath.startsWith('https://')) {
			return imagePath;
		}
		
		// 显示加载提示
		uni.showLoading({ 
			title: '正在下载...', 
			mask: true 
		});
		
		try {
			// 下载网络图片到本地
			const { tempFilePath } = await uni.downloadFile({
				url: imagePath,
				timeout: 600000 // 60秒超时
			});
			
			// 下载完成后隐藏加载提示
			uni.hideLoading();
			
			if (!tempFilePath) {
				throw new Error('下载失败，未获取到临时文件路径');
			}
			
			return tempFilePath;
		} catch (err) {
			// 下载失败时隐藏加载提示
			uni.hideLoading();
			throw new Error(`图片下载失败: ${err.message}`);
		}
	}

}