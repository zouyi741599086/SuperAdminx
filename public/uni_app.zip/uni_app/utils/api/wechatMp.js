import api from '../api.js';

/**
 * 微信服务号 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const wechatMpApi = {
    // 获取jssdk配置
    getJsSdkConfig: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/wechatMp/getJsSdkConfig', params, showLoading, showError, errDelStorage);
    },
	// 获取openid，第一步：获取网页授权url
	getOauthRedirectUrl: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.get('/app/user/api/wechatMp/getOauthRedirectUrl', params, showLoading, showError, errDelStorage);
	},
	// 获取openid，第二步：获取openid
	getUserByCode: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.get('/app/user/api/wechatMp/getUserByCode', params, showLoading, showError, errDelStorage);
	},
}