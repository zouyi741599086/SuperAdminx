import api from '../api.js';

/**
 * 文件 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const fileApi = {
    // 上传文件
    upload: (filePath, name = 'file', params = {}, showLoading = false) => {
        return api.upload('/app/file/api/File/upload', filePath, name, params, showLoading);
    },
    // 下载文件
    download: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/file/api/File/download',params, showLoading, showError, errDelStorage);
    },
        
}