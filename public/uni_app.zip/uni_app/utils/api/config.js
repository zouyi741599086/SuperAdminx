import api from '../api.js';

/**
 * 配置 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const configApi = {
	// 获取配置
	getConfig: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
		return api.get('/app/admin/api/Config/getConfig', params, showLoading, showError, errDelStorage);
	},

}