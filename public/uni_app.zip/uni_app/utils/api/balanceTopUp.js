import api from '../api.js';

/**
 * 余额提现 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const balanceTopUpApi = {
    // 充值
    pay: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.post('/app/balance/api/balanceTopUp/pay', params, showLoading, showError, errDelStorage);
    },
}