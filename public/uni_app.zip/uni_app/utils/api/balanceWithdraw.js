import api from '../api.js';

/**
 * 余额提现 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const balanceWithdrawApi = {
    // 列表
    getList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/BalanceWithdraw/getList', params, showLoading, showError, errDelStorage);
    },
    // 新增余额提现
    create: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.post('/app/balance/api/BalanceWithdraw/create', params, showLoading, showError, errDelStorage);
    },
    // 获取数据
    findData: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/BalanceWithdraw/findData', params, showLoading, showError, errDelStorage);
    },
    // 获取最后一次提现详情
    getLastInfo: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/BalanceWithdraw/getLastInfo', params, showLoading, showError, errDelStorage);
    },
}