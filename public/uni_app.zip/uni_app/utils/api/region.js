import api from '../api.js';

/**
 * 省市区 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const regionApi = {
    // 根据上级获取下级
    getList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/region/api/Region/getList', params, showLoading, showError, errDelStorage);
    },
    // 获取所有的省
    getProvince: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/region/api/Region/getProvince', params, showLoading, showError, errDelStorage);
    },
    // 获取所有的省市，多维的
    getProvinceCity: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/region/api/Region/getProvinceCity', params, showLoading, showError, errDelStorage);
    },
    // 获取所有省市区，多维的
    getListAll: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/region/api/Region/getListAll', params, showLoading, showError, errDelStorage);
    },
    // 获取省市区数据
    pathInfo: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/region/api/Region/pathInfo', params, showLoading, showError, errDelStorage);
    },  
}