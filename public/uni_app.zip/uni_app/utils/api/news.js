import api from '../api.js';

/**
 * 新闻 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const newsApi = {
	// 获取列表
	getList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
		return api.get('/app/news/api/News/getList',  params, showLoading, showError, errDelStorage);
	},
	// 获取文章
	findData: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
		return api.get('/app/news/api/News/findData',  params, showLoading, showError, errDelStorage);
	},
	// 增加浏览量
	incPv: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
		return api.get('/app/news/api/News/incPv',  params, showLoading, showError, errDelStorage);
	},
}