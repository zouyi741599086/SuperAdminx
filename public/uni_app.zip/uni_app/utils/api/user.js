import api from '../api.js';

/**
 * 用户 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const userApi = {
    // 获取自己的资料
    getUserInfo: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/User/getUserInfo', params, showLoading, showError, errDelStorage);
    },
    // 修改自己的资料
    updateInfo: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.post('/app/user/api/User/updateInfo', params, showLoading, showError, errDelStorage);
    },
    // 获取推广统计
    getChildrenTotal: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/User/getChildrenTotal', params, showLoading, showError, errDelStorage);
    },
	// 获取推广用戶
	getChildrenList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.get('/app/user/api/User/getChildrenList', params, showLoading, showError, errDelStorage);
	},
    // 获取推广统计 月走势图
    getChildrenTotalMonth: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/User/getChildrenTotalMonth', params, showLoading, showError, errDelStorage);
    },
	// 获取推广统计 日走势图
	getChildrenTotalDate: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.get('/app/user/api/User/getChildrenTotalDate', params, showLoading, showError, errDelStorage);
	},
    // 搜索某个用户，不能搜索自己
    searchUser: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/User/searchUser', params, showLoading, showError, errDelStorage);
    },
    // 更改手机号获取验证码
    getUpdateTelCode: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/user/api/User/getUpdateTelCode', params, showLoading, showError, errDelStorage);
    },
    // 获取推广二维码
    getShareQrcode: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.post('/app/user/api/User/getShareQrcode', params, showLoading, showError, errDelStorage);
    },  
	// 获取推广海报
	getSharePoster: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.post('/app/user/api/User/getSharePoster', params, showLoading, showError, errDelStorage);
	},
}