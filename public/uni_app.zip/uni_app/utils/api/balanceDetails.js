import api from '../api.js';

/**
 * 余额 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const balanceDetailsApi = {
    // 余额明细列表
    getList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/BalanceDetails/getList', params, showLoading, showError, errDelStorage);
    },
}