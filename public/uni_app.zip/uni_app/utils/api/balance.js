import api from '../api.js';

/**
 * 余额 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const balanceApi = {
    // 获取用户余额
    get: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/Balance/get', params, showLoading, showError, errDelStorage);
    },
	// 用户余额转账
	turn: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
	    return api.post('/app/balance/api/Balance/turn', params, showLoading, showError, errDelStorage);
	},
    // 获取余额类型的配置
    getBalanceConfig: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/balance/api/Balance/getBalanceConfig', params, showLoading, showError, errDelStorage);
    },
        
}