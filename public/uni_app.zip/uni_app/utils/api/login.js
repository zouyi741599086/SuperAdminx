import api from '../api.js';

/**
 * 登录 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const loginApi = {
	// 微信小程序自动登录
	weixinMiniAutoLogin: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
		return api.get('/app/user/api/Login/weixinMiniAutoLogin', params, showLoading, showError, errDelStorage);
	},
	// 微信小程序授权获取用户手机号
	mpWeixinGetPhoneNumber: (params = {}, showLoading = false, showError = true, errDelStorage = true, show = true) => {
		return api.get('/app/user/api/Login/mpWeixinGetPhoneNumber', params, showLoading, showError, errDelStorage);
	},
	// 手机号登录方式获取验证码
	getLoginCode: (params = {}, showLoading = false, showError = true, errDelStorage = true, show = true) => {
		return api.post('/app/user/api/Login/getLoginCode', params, showLoading, showError, errDelStorage);
	},
	// 注册或登录
	login: (params = {}, showLoading = false, showError = true, errDelStorage = true, show = true) => {
		return api.post('/app/user/api/Login/login', params, showLoading, showError, errDelStorage);
	},
}