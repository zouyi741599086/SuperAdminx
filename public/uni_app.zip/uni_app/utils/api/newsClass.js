import api from '../api.js';

/**
 * 新闻分类 API
 *
 * @author zy <741599086@qq.com>
 * @link https://www.superadminx.com/
 * */
export const newsClassApi = {
    // 获取所有分类
    getList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/news/api/NewsClass/getList', params, showLoading, showError, errDelStorage);
    },
    // 获取分类详情
    findData: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/news/api/NewsClass/findData', params, showLoading, showError, errDelStorage);
    },
    // 获取下级分类
    getChildrenList: (params = {}, showLoading = false, showError = true, errDelStorage = true) => {
        return api.get('/app/news/api/NewsClass/getChildrenList', params, showLoading, showError, errDelStorage);
    },
        
}