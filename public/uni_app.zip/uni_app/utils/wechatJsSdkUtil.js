import util from './util.js';
// #ifdef H5
import wx from 'weixin-js-sdk'
// #endif
import { wechatMpApi } from '@/utils/api/wechatMp.js';
import { useUserStore } from '@/store/user';

// 添加状态变量
let isInitialized = false;
let initPromise = null;
// 默认分享配置变量
let defaultShareConfig = {};

/**
 * 微信公众号分享工具
 * App.vue 里面引入，并增加share方法
 * 然后每个页面都需要调用 app.globalData.share(); 参数看下面
 */
export default {
	/**
	 * 初始化微信配置和分享配置
	 */
	initConfig() {
		// 如果正在初始化，返回相同的 Promise
		if (initPromise) {
			return initPromise;
		}

		// 如果已经初始化，返回已完成的 Promise
		if (isInitialized) {
			return Promise.resolve();
		}

		// 创建初始化 Promise
		initPromise = new Promise((resolve, reject) => {
			// 并行获取微信配置和分享配置
			Promise.all([
				wechatMpApi.getJsSdkConfig({
					url: window.location.origin + window.location.pathname
				}),
				util.getConfig('share_wechat_config')
			]).then(([jsSdkConfig, shareConfigRes]) => {
				// 保存分享配置
				defaultShareConfig = shareConfigRes || {};

				// 注入微信 JSSDK config 配置
				wx.config({
					debug: false,
					appId: jsSdkConfig.data.appId,
					timestamp: jsSdkConfig.data.timestamp + '',
					nonceStr: jsSdkConfig.data.nonceStr,
					signature: jsSdkConfig.data.signature,
					jsApiList: jsSdkConfig.data.jsApiList,
				});

				// 监听 config 完成
				wx.ready(() => {
					isInitialized = true;
					resolve();
				});

				// 监听 config 错误
				wx.error((error) => {
					reject(error);
				});

			}).catch(error => {
				reject(error);
			});
		});

		return initPromise;
	},

	/**
	 * 分享，三种情况
	 * 1、大家都能进的页面不管是否需要登录，直接分享当前页面出去就行，因为没登录会自动跳首页或登录页
	 * 2、像自己的订单详情、编辑收货地址页面这种带自己的id参数的，这种肯定是分享首页出去
	 * 3、需要权限才能进的页面，如代理商页面，肯定是分享首页出去
	 * 要控制分享的页面：直接控制 path 参数即可
	 * @param {object} _shareConfig
	 *  - title 标题
	 *  - path 路劲，如 /pages/news/info/index 会自动带上当前页面参数 及 用户的推广id
	 *  - img 图片
	 */
	async share(_shareConfig = {}) {
		// 如果未初始化，先初始化
		if (!isInitialized) {
			await this.initConfig();
		}
		
		const user = useUserStore();
		const link = this.getH5ShareUrl(user.data?.id || '', _shareConfig.path || '');
		
		// 默认标题等于页面的title 加 后台设置的
		if (! _shareConfig.title) {
			_shareConfig.title = `${document.title}-${defaultShareConfig.share_title}`;
		}

		// 优先使用传入的参数，其次使用配置中的默认值
		const shareTitle = _shareConfig.title || defaultShareConfig.share_title || '';
		const shareDesc = defaultShareConfig.share_desc || '';
		const shareImg = _shareConfig.img || defaultShareConfig.share_img || '';

		// 新版的控制分享
		try {
			wx.updateAppMessageShareData({
				title: shareTitle,
				desc: shareDesc,
				link: link,
				imgUrl: shareImg,
				success: function() {
				},
				fail: function(error) {
					console.error('分享到好友配置失败:', error);
				}
			});
			wx.updateTimelineShareData({
				title: shareTitle,
				link: link,
				imgUrl: shareImg,
				success: function() {
				},
				fail: function(error) {
					console.error('分享到朋友圈配置失败:', error);
				}
			});
		} catch (err) {
			wx.onMenuShareAppMessage({
				title: shareTitle,
				desc: shareDesc,
				link: link,
				imgUrl: shareImg,
				success: function() {
				},
				fail: function(error) {
					console.error('分享到好友配置失败:', error);
				}
			});
			
			wx.onMenuShareTimeline({
				title: shareTitle,
				link: link,
				imgUrl: shareImg,
				success: function() {
				},
				fail: function(error) {
					console.error('分享到朋友圈配置失败:', error);
				}
			});
		}
	},

	/**
	 * h5的时候获取当前页面的url，如果登录则自动加上当前用户id
	 * @param {int|string} user_id
	 * @param {string} path 如 /pages/news/info/index  会自动带上当前页面地址及登录用户的推广id
	 */
	getH5ShareUrl(user_id = null, path = null) {
		const url = window.location.href;
		const params = {};
		if (user_id) {
			params.invite_code = `from_id_${user_id}`;
		};

		// 解析URL，分离hash部分和基础部分
		const hashIndex = url.indexOf('#');
		let baseUrl = '';
		let hashPart = '';

		if (hashIndex !== -1) {
			baseUrl = url.substring(0, hashIndex);
			hashPart = url.substring(hashIndex);
		} else {
			baseUrl = url;
		}

		// 解析hash部分中的查询参数
		let hashPath = hashPart;
		let hashQueryString = '';
		let queryParams = {};

		// 检查hash部分是否包含查询参数
		const questionMarkIndex = hashPart.indexOf('?');
		if (questionMarkIndex !== -1) {
			hashPath = hashPart.substring(0, questionMarkIndex);
			hashQueryString = hashPart.substring(questionMarkIndex + 1);

			// 解析现有的查询参数
			const searchParams = new URLSearchParams(hashQueryString);
			for (const [key, value] of searchParams) {
				queryParams[key] = value;
			}
		}

		if (path) {
			hashPath = `#${path}`;
		}

		// 合并参数（新参数会覆盖旧参数）
		const mergedParams = {
			...queryParams,
			...params
		};

		// 构建新的查询字符串
		const newQueryString = Object.entries(mergedParams)
			.map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
			.join('&');

		// 构建新的hash部分
		const newHashPart = newQueryString ?
			`${hashPath}?${newQueryString}` :
			hashPath;

		// 组合成新的URL
		return baseUrl + newHashPart;
	}
}