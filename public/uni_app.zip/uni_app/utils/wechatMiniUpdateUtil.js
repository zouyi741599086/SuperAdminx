import util from './util.js';

/**
 * 微信小程序更新
 */
export default {
	/**
	 * 更新
	 */
	update() {
		// #ifdef MP
		const updateManager = uni.getUpdateManager();
		if (updateManager) {
			// 从朋友圈打开是没有的
			updateManager.onCheckForUpdate(function(res) {
				// 请求完新版本信息的回调
			});
			updateManager.onUpdateReady(function() {
				util.modal({
					title: '更新提示',
					content: '新版本已经准备好，是否马上重启应用？',
				}).then(res => {
					// 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
					updateManager.applyUpdate();
				})
			});
		}
		// #endif
	},
}