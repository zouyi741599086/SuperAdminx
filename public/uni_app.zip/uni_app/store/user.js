import {
	defineStore
} from 'pinia'
import { userApi } from '@/utils/api/user';

// 第一个参数是应用程序中 store 的唯一 id
export const useUserStore = defineStore('user', {
	state: () => {
		return {
			data: {}, //登录用户资料
		}
	},
	actions: {
		update() {
			return userApi.getUserInfo({},false,false,false).then(res => {
				this.data = res.data;
				return res.data;
			})
		},
	},
	persist: {
		storage: {
			getItem: uni.getStorageSync,
			setItem: uni.setStorageSync
		}
	}
})