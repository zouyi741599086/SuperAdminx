import {
	defineStore
} from 'pinia'
import { balanceApi } from '@/utils/api/balance';

// 第一个参数是应用程序中 store 的唯一 id
export const useBalanceStore = defineStore('balance', {
	state: () => {
		return {
			data: {}, //用户的余额
		}
	},
	actions: {
		update() {
			return balanceApi.get().then(res => {
				this.data = res.data;
				return res.data;
			});
			
		},
	},
	persist: {
		storage: {
			getItem: uni.getStorageSync,
			setItem: uni.setStorageSync
		}
	}
})