import { defineStore } from 'pinia'

// 第一个参数是应用程序中 store 的唯一 id
export const useSystemInfoStore = defineStore('systemInfo', {
    state: () => {
        return {
            data: {}, //设备信息
        }
    },
	actions: {
		update() {
			this.data = uni.getSystemInfoSync();
		},
	},
	persist: {
		storage: {
			getItem: uni.getStorageSync,
			setItem: uni.setStorageSync
		}
	}
})