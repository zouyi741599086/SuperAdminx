import { configApi } from '@/utils/api/config.js'

// app的更新检测，此文件不能改名，不能变位置，插件强制要求，https://ext.dcloud.net.cn/plugin?id=1643
const platform = uni.getSystemInfoSync().platform;
export default {
    // 发起ajax请求获取服务端版本号
    getServerNo: (version, isPrompt = false, callback) => {
		configApi.getConfig({name: 'app_update'}).then(res => {
			//console.log(res.data);
			let dataInfo = res.data;
			let backInfo = {};
			if (platform == "android") {
				if(dataInfo.android_version != version.versionName){
					backInfo = {
						versionCode: version.versionCode,
						versionName: version.versionName,
						versionInfo: dataInfo.android_update_content,
						updateType: 'forcibly', // forcibly = 强制更新, solicit = 弹窗确认更新, silent = 静默更新
						downloadUrl: dataInfo?.android_url
					};
					callback && callback(backInfo);
				}
			} else {
				if(dataInfo.ios_version != version.versionName){
					backInfo = {
						versionCode: version.versionCode,
						versionName: version.versionName,
						versionInfo: dataInfo.ios_update_content,
						updateType: 'forcibly',
						downloadUrl: dataInfo?.ios_url
					};
					callback && callback(backInfo);
				}
			}
		})
       
    },
    // 弹窗主颜色（不填默认粉色）
    appUpdateColor: "FF4826",
    // 弹窗图标（不填显示默认图标，链接配置示例如： '/static/demo/ic_attention.png'）
    appUpdateIcon: ''
}