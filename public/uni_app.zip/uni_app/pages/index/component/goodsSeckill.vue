<template>
	<view class="warp" v-if="list.length > 0">
		<wd-gap height="10rpx"></wd-gap>
		<view class="seckill" >
			<view class="seckill-top">
				<view class="l">
					<image :src="`${app.globalData.staticURL}/seckill.png`" class="img"/>
					<text class="txt">
						{{seckillStatus == 1 ? '距离开始' : ''}}
						{{seckillStatus == 2 ? '距离结束' : ''}}
						{{seckillStatus == 3 ? '活动已结束' : ''}}
					</text>
					<wd-count-down 
						:time="countdown * 1000" 
						custom-class="down"
						@finish="finish()"
					>
						<template #default="{ current }">
							<view class="custom-count">
								<text class="custom-count-down">
									{{ current.hours < 10 ? `0${current.hours}` : current.hours }}
								</text>
								<text class="custom-count-down">
									{{ current.minutes < 10 ? `0${current.minutes}` : current.minutes }}
								</text>
								<text class="custom-count-down">
									{{ current.seconds < 10 ? `0${current.seconds}` : current.seconds }}
								</text>
							</view>
					  </template>
					</wd-count-down>
				</view>
				<view class="r">
					<navigator url="/pagesShop/seckill/index" hover-class="none">
						<image :src="`${app.globalData.staticURL}/more.png`" class="img" />
					</navigator>
				</view>
			</view>
			
			<goods-ceckill-list 
				:list="list"
				:goodsStatus="seckillStatus"
			/>
		</view>
		<wd-gap height="10rpx"></wd-gap>
	</view>
</template>

<script setup>
	import { ref ,onMounted} from 'vue';
	import { shopSeckillTimeApi } from '@/utils/api/shopSeckillTime';
	import { shopGoodsApi } from '@/utils/api/shopGoods';
	
	const app = getApp();
	
	const countdown = ref(0); // 秒杀刷新倒计时
	const seckillStatus = ref(0); // 秒杀状态
	
	const list = ref([]); // 秒杀商品列表
	
	onMounted(() => {
		getShopSeckillTime();
	})
	
	// 获取秒杀时间段配置，获取当前是哪个时间段场次
	const getShopSeckillTime = () => {
		shopSeckillTimeApi.getList({},false,false).then(res => {
			seckillStatus.value = res.data.list[res.data.index].status;
			countdown.value = res.data.countdown;
			getList(res.data.list[res.data.index].id);
		}).catch(err => {
		})
	}
	
	/**
	 * 获取秒杀商品列表
	 * @param {Number} shop_seckill_time_id 时间段场次ID
	 */
	const getList = (shop_seckill_time_id) => {
		shopGoodsApi.getList({
			goods_type: 3,
			shop_seckill_time_id
		}).then(res => {
			list.value = res.data.data.slice(0, 3);
		})
	}
	
	// 倒计时结束
	const finish = () => {
		if (countdown.value > 0) {
			getShopSeckillTime();
		}
	}
	
	// 暴露给父组件
	defineExpose({
	  refresh: () => getShopSeckillTime()
	});
	
</script>

<style lang="scss" scoped>
	// 秒杀
	.warp{margin: 0 24rpx;}
	.seckill{padding: 24rpx;border-radius: 32rpx;background: linear-gradient(to bottom, #ffffff 0%, #FFF8EC 100%); border: 6rpx solid #ffffff;}
	.seckill .seckill-top{width:100%;height:auto;display: flex;}
	.seckill .seckill-top .l{flex:1;display: flex;align-items: center;}
	.seckill .seckill-top .l .img{height:48rpx;width:96rpx;}
	.seckill .seckill-top .l .txt{display: inline-block;padding-left:20rpx;font-size:24rpx;color:#666;}
	.custom-count{display: flex;gap:0rpx 6rpx;padding-left:10rpx;}
	.custom-count .custom-count-down{font-size:24rpx;background: #f8af60;width:36rpx;text-align: center;height:36rpx;border-radius: 6rpx;display: flex;align-items: center;justify-content: center;color:#fff;}
	.seckill .seckill-top .r .img{width:40rpx;height:40rpx;}
</style>
