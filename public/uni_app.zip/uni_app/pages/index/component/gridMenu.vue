<template>
	<wd-transition :show="true" name="fade">
		<view 
			class="area-warp"
			:style="`padding: ${padding};`"
		>
			<wd-skeleton
				:row-col="[
					[
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
					],
					[
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
						{width: '48px', height: '48px'},
					]
				]" 
				animation="gradient"
				:loading="iconList.length == 0"
			>
				<view 
					class="area-category"
					:style="`grid-template-columns: repeat(${col}, 1fr);`"
				>
					<template v-for="(item,index) in iconList" :key="index">
						<view class="c-item" @click="toPages(item)">
							<image :src="item.img" class="img"></image>
							<text class="txt">{{item.title}}</text>
						</view>
					</template>
				</view>
			</wd-skeleton>
		</view>
	</wd-transition>
	<!-- 分享弹窗 -->
	<share ref="shareRef" :safeAreaInsetBottom="false"/>
</template>

<script setup>
	// 九宫格菜单
	import { ref, watch, onMounted } from 'vue';
	
	const app = getApp();
	const props = defineProps({
		// list 跟 name 传一个就可以了
		// 数据
		list: {
			type: Array,
			default: [], // url属性可以等于连接，也可以等于：share》分享，
		},
		// 获取配置的名称
		name: {
			type: String,
			default: null
		},
		// 容器内边距
		padding: {
			type: String,
			default: '0rpx 24rpx'
		}
	})
	
	// 数据
	const iconList = ref([]);
	// 一行占几个
	const col = ref(4);
	// 分享弹窗
	const shareRef = ref();
	
	onMounted(() => {
		
	})
	
	// 获取数据
	const getData = () => {
		if (props.list.length > 0) {
			iconList.value = props.list;
			return;
		}
		if (props.name) {
			app.globalData.util.getConfig(props.name).then(res => {
				iconList.value = res
			})
		}
	}
	
	// 监听参数变化
	watch(() => [props.list, props.name], () => {
		getData();
	}, { immediate: true, deep: true });
	
	// 监听数据变化的时候，变化一行几个图标
	watch(() => [iconList.value], () => {
		let length = iconList.value?.length;
		if (length <= 5) {
			col.value = 5;
		}
		if (length > 5 && length <= 8) {
			col.value = 4;
		}
		if (length > 8) {
			col.value = 5;
		}
	})
	
	// 暴露方法给父组件
	defineExpose({
		refresh: () => getData(),
	})
	
	// 跳转页面
	const toPages = (item) => {
		// 如果是分享
		if (item.url == 'share') {
			shareRef.value.changeShow();
			return;
		}
		if (item.url) {
			app.globalData.util.toPages(item.url)
		}
	}
	
</script>

<style lang="scss" scoped>
	.area-warp{}
	.area-category{display: grid;grid-template-columns: repeat(4, 1fr);justify-items: center;gap: 32rpx 0rpx;border-radius: 32rpx;background: linear-gradient(to bottom, #ffffff 0%, var(--superadminx-color-light1) 100%); border: 6rpx solid #ffffff;padding:40rpx 8rpx;}
	.area-category .c-item{display: flex;flex-direction: column;align-items: center;}
	.area-category .c-item .img{width: 80rpx;height: 80rpx;border-radius: 50%;margin-bottom: 12rpx;}
	.area-category .c-item .txt{font-size: 28rpx;line-height: 32rpx;text-align: center;font-weight: 500;}
</style>
