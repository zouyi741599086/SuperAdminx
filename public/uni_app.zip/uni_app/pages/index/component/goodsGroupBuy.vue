<template>
	<template v-if="list.length > 0">
		<view class="warp">
			<wd-gap height="10rpx"></wd-gap>
			<view class="group" >
				<view class="group-top">
					<view class="l">
						<image :src="`${app.globalData.staticURL}/group.png`" class="img"/>
						<text class="txt">拼实惠</text>
					</view>
					<view class="r">
						<navigator url="/pagesShop/groupBuy/index" hover-class="none">
							<image :src="`${app.globalData.staticURL}/more-green.png`" class="img" />
						</navigator>
					</view>
				</view>
				<scroll-view class="group-main" scroll-x>
					<template  v-for="(item, index) in list" :key="index">
						<view  
							@click="app.globalData.util.toPages(`/pagesShop/goodsInfo/index?id=${item.id}`);"
							class="item"
						>
							<image :src="item.img" class="img" />
							<view class="info-box">
								<view class="title">
									<text class="txt">{{item.title}}</text>
								</view>
								<view class="c-yprice">
									<text class="txt">原价￥{{item.show_market_price}}</text>
								</view>
								<view class="c-price">
									<price :price="item.show_price"/>
								</view>
							</view>
						</view>
					</template>
					
				</scroll-view>
			</view>
			<wd-gap height="10rpx"></wd-gap>
		</view>
	</template>
</template>

<script setup>
	import { ref ,onMounted} from 'vue';
	import { useRaceSafeList } from '@/utils/useListRequest.js';
	import { shopGoodsApi } from '@/utils/api/shopGoods';
	
	const app = getApp();
	
	
	// 今日必团
	const {
		list,
		refresh
	} = useRaceSafeList({
		api: shopGoodsApi.getList,  
		params: {       
			goods_type: 2,
			order: 7 // 按照id倒序
		},
		pageSize: 10,
	});
	
	onMounted(() => {
		
	})
	
	
	// 刷新数据
	const refreshData = () => {
		list.value = [];
		getList();
	}
	
	// 暴露给父组件
	defineExpose({
	  refreshData
	});
	
</script>

<style lang="scss" scoped>
	// 秒杀
	.warp{margin: 0 24rpx;}
	.group{padding: 24rpx;border-radius: 32rpx;background: linear-gradient(to bottom, #ffffff 0%, #e6fff8 100%); border: 6rpx solid #ffffff;}
	.group .group-top{width:100%;height:auto;display: flex;}
	.group .group-top .l{flex:1;display: flex;align-items: center;}
	.group .group-top .l .img{height:48rpx;width:104rpx;}
	.group .group-top .l .txt{display: inline-block;padding-left:20rpx;font-size:24rpx;color:#666;}
	.group .group-top .r .img{width:40rpx;height:40rpx;}
	.group .group-main{overflow-x:auto;white-space:nowrap;margin-top:28rpx;}
	
	.group .group-main .item{display: inline-block;width:220rpx;border-radius: 6rpx;overflow: hidden;background-color: #fff;margin-right:16rpx;}
	.group .group-main .item:last-child{margin-right:0rpx;}
	.group .group-main .item .img{width:220rpx;height:220rpx;}
	.group .group-main .item .info-box{width:auto;margin:8rpx;overflow: hidden;}
	.group .group-main .item .info-box .title{width:100%;overflow: hidden;;height:36rpx;text-overflow:ellipsis;white-space:nowrap;}
	.group .group-main .item .info-box .title .txt{font-size:28rpx;line-height: 36rpx;font-weight: 500;}
	.group .group-main .item .info-box .c-yprice .txt{font-size:22rpx;color:#999;text-decoration: line-through;}
	.group .group-main .item .info-box .c-price{display: flex;padding:10rpx 0rpx 0rpx;}
</style>
