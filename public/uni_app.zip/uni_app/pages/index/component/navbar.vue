<template>
	<view class="custom-navbar">
		<wd-navbar
			:safeAreaInsetTop="true"
			:bordered="false"
			:custom-style="'background-color: transparent;'"
			custom-class="home-top-navbar"
		>
			<template #left>
				<image 
					:src="`${app.globalData.staticURL}/logo.png`"
					mode="heightFix"
					class="logo"
				/>
			</template>
			<template #title>
				<view 
					class="custom-search"
					:style="`padding-right:${boundingClientRect.width}px`"
				>
					<wd-search
						custom-class="top-search"
						placeholder="搜索商品"
						hide-cancel
						disabled
						placeholder-left
						:light="true"
						@click="app.globalData.util.toPages('/pagesShop/goodsSearch/index')"
					></wd-search>
				</view>
			</template>
		</wd-navbar>
	</view>
</template>

<script setup>
	import { ref, watch, onMounted } from 'vue';
	
	const app = getApp();
	const props = defineProps({
		
	})
	
	const boundingClientRect = ref({width:12}); // 如果是小程序平台则获取胶囊的位置
	
	// 共享样式
	defineOptions({
		options: { 
			styleIsolation: 'shared',
		} ,
	});
	
	onMounted(() => {
		// 如果是小程序，则获取胶囊的位置
		// #ifdef MP
		let _boundingClientRect = uni.getMenuButtonBoundingClientRect();
		_boundingClientRect.width += 16;
		boundingClientRect.value = _boundingClientRect;
		// #endif
	})
	
	
</script>

<style lang="scss" scoped>
	.custom-navbar::v-deep .wd-navbar__content{width:100%;display: flex;}
	.custom-navbar::v-deep .wd-navbar__content .wd-navbar__left{width:auto;position: relative;max-width:180rpx;}
	.custom-navbar::v-deep .wd-navbar__title{max-width:100%;flex:1;}
	.custom-navbar::v-deep .wd-navbar__title .wd-search{background: transparent;text-align: left;padding:7px 0px 7px 0px;}
	
	/*  #ifdef  MP  */
	.custom-navbar::v-deep .wd-navbar__title .wd-search{padding-top:6px;}
	/*  #endif  */
	
	.logo{height:40rpx;}
	
</style>
