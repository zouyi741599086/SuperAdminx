<template>
	<view 
		class="runxue"
	>
		
	</view>
	
</template>

<script setup>
	import { onLoad, onReady, onShow, onUnload, onReachBottom, onPullDownRefresh, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app';
	import { ref,computed, nextTick} from 'vue';
	import { useRaceSafeList } from '@/utils/useListRequest.js';
	
	const app = getApp();
	
	
	onLoad(() => {
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage();
	}) 
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline();
	})
	
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background-color:#f5f5f5;width: 100%;background-image: linear-gradient(to bottom, var(--superadminx-color-light1), #f5f5f5); background-repeat: no-repeat; background-position: top;}
</style>
