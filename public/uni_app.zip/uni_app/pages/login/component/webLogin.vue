<template>
	<view class="h5-login-form">
		<view class="row-form-item">
			<wd-icon
				name="phone"
				custom-class="c-title"
			></wd-icon>
			<view class="c-right">
				<input 
					type="number" 
					v-model="formData.tel" 
					class="c-input" 
					placeholder="请输入手机号" 
					placeholder-class="input-placeholder"
					:maxlength="11"
				/>
			</view>
		</view>
		<view class="row-form-item">
			<wd-icon 
				name="secured"
				custom-class="c-title"
			></wd-icon>
			<view class="c-right">
				<input 
					type="number" 
					v-model="formData.code"
					placeholder="请输入验证码"
					class="c-input"
					:maxlength="6"
				/>
				<text 
					class="btn-yzm" 
					v-if="!showTime"
					@click="toGetCode"
				>获取验证码</text>
				<view class="btn-yzm on" v-else>
					<wd-count-down
						:time="60 * 1000"
						format="sss后再次获取"
						custom-class="count-time"
						@finish="showTimeChange"
					/>
				</view>
			</view>
		</view>
		<button class="r-btn" @click="login">登录</button>
	</view>
</template>

<script setup>
	// 微信登录注册
	import { ref, computed, onMounted} from 'vue';
	import { loginApi } from '@/utils/api/login.js';
	import { useUserStore } from '@/store/user.js';
	import { useBalanceStore } from '@/store/balance.js';
	// #ifdef H5
	// 公众号获取openid
	import wechatMpOpenidUtil from '@/utils/wechatMpOpenidUtil.js';
	// #endif
	
	const app = getApp();
	const props = defineProps({
		// 是否已同意协议
		checked: {
			type: Boolean,
			default: false
		}
	})
	
	onMounted(() => {
		// 如果是微信浏览器同时本地没得weixin_mp_openid的时候，则先去获取
		if (app.globalData.util.isWeChatBrowser() && ! uni.getStorageSync('weixin_mp_openid')) {
			wechatMpOpenidUtil.init();
		}
	})
	
	// 提交内容
	const formData = ref({
		tel: '',
		code: '',
	});
	const showTime = ref(false); // 是否能获取验证码
	
	// 获取验证码
	const toGetCode = () => {
		if(showTime.value){
			return;
		}
		if(!formData.value.tel){
			return app.globalData.util.toast('请输入手机号'); 
		}
		if(!app.globalData.util.checkTel(formData.value.tel)){
			return app.globalData.util.toast('请输入正确的手机号');
		}
		loginApi.getLoginCode({
			tel: formData.value.tel
		}).then((res) => {
			showTime.value = true;
			app.globalData.util.toast(res.message);
		})
	}
	
	// 验证码倒计时结束
	const showTimeChange = () => {
		showTime.value = !showTime.value;
	}
	
	const login = () => {
		if(! formData.value.tel){
			return app.globalData.util.toast('请输入手机号'); 
		}
		if(!app.globalData.util.checkTel(formData.value.tel)){
			return app.globalData.util.toast('请输入正确的手机号');
		}
		if(!formData.value.code){
			return app.globalData.util.toast('请输入验证码'); 
		}
		if(! props.checked){
			return app.globalData.util.toast('请阅读并同意用户隐私协议'); 
		}
		loginApi.login({
			tel: formData.value.tel,
			sms_code: formData.value.code,
			invite_code: uni.getStorageSync('invite_code'), // 推荐人
			weixin_mp_openid: uni.getStorageSync('weixin_mp_openid'), // 微信公众号openid
			weixin_unionid: uni.getStorageSync('weixin_unionid'), // 微信的unionid
		},true).then(res => {
			const user = useUserStore();
			user.data = res.data;
			uni.setStorageSync('token', res.data.token);
			
			// 获取余额信息
			const balance = useBalanceStore();
			balance.update();
			
			app.globalData.util.toast(res.message || '登录成功');
			setTimeout(() => {
				app.globalData.util.backPage();
			}, 1500);
		})
		
	}
	
</script>

<style>
	page{background:#fff;}
</style>
<style lang="scss" scoped>
	.h5-login-form{margin-top: 80rpx;padding: 0 50rpx;width:100%;box-sizing: border-box;}
	.h5-login-form .row-form-item{height: 90rpx;border-radius: 45rpx;background: #ffffff; display: flex;align-items: center;font-size: 28rpx;line-height: 60rpx;border: 2rpx solid var(--superadminx-color-light1);box-shadow: 7rpx 0rpx 22rpx 0rpx var(--superadminx-color-light1);margin-bottom: 30rpx;box-sizing: border-box;overflow: hidden;padding: 0 30rpx;}
	::v-deep .h5-login-form .row-form-item .c-title{font-size: 36rpx;color: #666;}
	.h5-login-form .row-form-item .c-right{flex: 1; display: flex;align-items: center;padding: 0;margin: 0;background-color: transparent;position: relative;margin-left:20rpx;}
	.h5-login-form .row-form-item .c-input{flex: 1;line-height: 72rpx;height: 72rpx;font-size: 28rpx;text-align: left;}
	.h5-login-form .row-form-item .btn-yzm{margin-left: 20rpx;height: 60rpx;line-height: 60rpx;text-align: center;border-radius: 30rpx;background: var(--superadminx-color-light1);color: var(--superadminx-color);font-size: 24rpx;margin-left: 30rpx;padding:0px 20rpx;display: flex;align-items: center;}
	.h5-login-form .row-form-item .btn-yzm.on{background: #e1e4ef;color: #999999;}
	.h5-login-form .row-form-item :deep(.wd-count-down){color: #999999;}
	.h5-login-form .row-form-item:focus-within{border: 2rpx solid var(--superadminx-color);}
	.h5-login-form .r-btn{width: 600rpx;height: 90rpx;border-radius: 45rpx;background: var(--superadminx-color);color: #ffffff;line-height: 90rpx;font-size: 36rpx;font-weight: normal;margin-top: 20rpx;margin-bottom: 30rpx;}
	
	button::after{border: none;}
</style>
