<template>
	<button 
		class="weixin-mini-getphone" 
		open-type="getPhoneNumber"
		@getphonenumber="getPhoneNumber"
		v-if="checked"
	>手机号快捷登录</button>
	<button 
		class="weixin-mini-getphone" 
		@click="app.globalData.util.toast('请先同意用户隐私协议')"
		v-else
	>手机号快捷登录</button>
</template>

<script setup>
	// 微信登录注册
	import { ref, computed, onMounted, onBeforeUnmount} from 'vue';
	import { loginApi } from '@/utils/api/login.js';
	import { useUserStore } from '@/store/user.js';
	import { useBalanceStore } from '@/store/balance.js';
	
	const app = getApp();
	const props = defineProps({
		// 是否已同意协议
		checked: {
			type: Boolean,
			default: false
		}
	})
	
	onBeforeUnmount(() => {
		uni.hideLoading();
	})
	
	// 授权获取手机号
	const getPhoneNumber = (e) => {
		if(! props.checked){
			return app.globalData.util.toast('请先阅读并同意用户隐私协议');
		}
		if (e.detail.errMsg == 'getPhoneNumber:ok') {
			uni.showLoading();
			loginApi.mpWeixinGetPhoneNumber({
				code: e.detail?.code
			}).then((res) => {
				login(res.data);
			}).catch(err => {
				uni.hideLoading();
			});
		} else {
			app.globalData.uril.toast('手机号码授权失败');
		}
	}
	
	// 登录
	const login = (tel) => {
		uni.login({
			success: (res) => {
				if (res.code) {
					loginApi.login({
						code: res.code,
						tel: tel,
						invite_code: uni.getStorageSync('invite_code'), // 推荐人
					}).then((res) => {
						const user = useUserStore();
						user.data = res.data;
						uni.setStorageSync('token', res.data.token);
						
						// 获取余额信息
						const balance = useBalanceStore();
						balance.update();
						
						app.globalData.util.toast(res.message || '登录成功');
						setTimeout(() => {
							app.globalData.util.backPage();
						}, 1500);
						uni.hideLoading();
					}).catch(err => {
						uni.hideLoading();
					});
				}
			},
			fail: err => {
				// console.log(err);
			}
		});
	}
	
</script>

<style>
	page{background:#fff;}
</style>
<style lang="scss" scoped>
	.weixin-mini-getphone{width: 600rpx;height: 90rpx;border-radius: 45rpx;background: var(--superadminx-color);color: #ffffff;line-height: 90rpx;font-size: 36rpx;font-weight: normal;margin-top: 200rpx;margin-bottom: 30rpx;}
</style>
