<template>
	<view class="runxue">
		<view class="page-main">
			<image 
				:src="`${app.globalData.staticURL}/logo.png`" 
				mode="widthFix" 
				class="r-logo"
			></image>
			<!-- #ifdef MP-WEIXIN -->
				<weixinMini :checked="checked"/>
			<!-- #endif -->
			
			<!-- #ifdef WEB || H5 -->
				<webLogin :checked="checked"/>
			<!-- #endif -->
			
			<!-- #ifdef APP -->
				<appLogin :checked="checked"/>
			<!-- #endif -->
			
			<button class="r-btn-2" @click="app.globalData.util.backPage()">返回</button>
			<view class="r-xx" @click="checked = !checked">
				<wd-icon
					custom-class="c-tb"
					:name="checked ? 'check-circle-filled' : 'circle1'"
					:color="checked ? 'var(--superadminx-color)' : '#999'"
				></wd-icon>
				我已阅读并同意
				<text 
					class="c-link"
					@click.stop="app.globalData.util.toPages('/pagesOther/page/index?name=user_agreement&title=用户协议')"
				>《用户协议》</text>
				<text 
					class="c-link" 
					@click.stop="app.globalData.util.toPages('/pagesOther/page/index?name=privacy_policy&title=隐私协议')"
				>《隐私协议》</text>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow,onReady, onUnload, onReachBottom, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import weixinMini from './component/weixinMini.vue';
	import webLogin from './component/webLogin.vue';
	import appLogin from './component/appLogin.vue';
	
	const app = getApp();
	const checked = ref(false);
	
	onLoad((options) => {
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	onReady(() => {
		
	})
	onUnload(() => {
	})
	
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({title: '登录'});
	}) 
	
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline({title: '登录'});
	})
</script>

<style>
	page{background:#fff;}
</style>
<style lang="scss" scoped>
	.runxue{background:#fff;}
	.page-main{padding: 180rpx 20rpx;display: flex;flex-direction: column;align-items: center;justify-content: center;box-sizing: border-box;}
	.page-main .r-logo{width: 180rpx;height: 180rpx;display: block;}
	.r-btn-2{width: 600rpx;height: 90rpx;border-radius: 45rpx;background: #eaeaea;color: #999999;line-height: 90rpx;font-size: 36rpx;font-weight: normal;margin-bottom: 30rpx;}
	.page-main .r-xx{font-size: 28rpx;color: #999999;text-align: center;display: flex;align-items: center;}
	::v-deep .page-main .r-xx .c-tb{font-size: 36rpx;margin-right: 4rpx;}
	.page-main .r-xx  .c-link{color: var(--superadminx-color);}
	
	button::after{border: none;}
</style>
