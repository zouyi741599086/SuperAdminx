<template>
	<view class="runxue">
		<view 
			class="area-top-box flex" 
			:style="`padding-top:${systemInfo.data?.safeAreaInsets?.top + 50}px`"
			@click.stop="app.globalData.util.toPages('/pagesUser/setting/index',false, true)"
		>
			<view class="c-img">
				<image 
					:src="user.data?.img || `${app.globalData.staticURL}/tb-tx.png`" 
					mode="aspectFill" 
					class="img"
				></image>
			</view>
			<view class="c-info">
				<view class="con">
					<view class="name">{{user.data?.name || '未登录'}}</view>
					<view class="desc">{{user.data?.tel}}</view>
				</view>
			</view>
			<topMessage ref="topMessageRef"/>
		</view>
		
		<!-- 优惠券 收藏 -->
		<template1 ref="template1Ref"/>
		
		<!-- 订单统计 -->
		<orderStatus ref="orderStatusRef"/>
		
		<!-- 余额模块 -->
		<balanceTemplate ref="balanceTemplateRef"/>
		
		<!-- 菜单模块 -->
		<menuTemplate />
	</view>
</template>

<script setup>
	import { onLoad, onShow, onPageScroll, onPullDownRefresh, onShareAppMessage, onShareTimeline } from '@dcloudio/uni-app';
	import { ref, computed, nextTick } from 'vue';
	import { useSystemInfoStore } from '@/store/systemInfo';
	import { useUserStore } from '@/store/user';
	import topMessage from './component/topMessage.vue';
	import template1 from './component/template1.vue';
	import orderStatus from './component/orderStatus.vue';
	import balanceTemplate from './component/balanceTemplate.vue';
	import menuTemplate from './component/menuTemplate.vue';
	
	const app = getApp();
	const systemInfo = useSystemInfoStore(); // 设备信息
	const user = useUserStore(); // 用户信息
	
	const topMessageRef = ref(); // 顶部消息
	const template1Ref = ref(); // 优惠券收藏模块
	const orderStatusRef = ref(); // 订单模块
	const balanceTemplateRef = ref(); // 余额模块
	
	onLoad(() => {
	});
	
	onShow(() => {
		const isLogin = app.globalData.util.isLogin();
		nextTick(() => {
			topMessageRef.value.refresh(isLogin);
			template1Ref.value.refresh(isLogin);
			orderStatusRef.value.refresh(isLogin);
			balanceTemplateRef.value.refresh(isLogin);
		})
		
		// 公众号分享
		app.globalData.share();
	})
	
	onShareAppMessage(() => {
		return app.globalData.onShareAppMessage({title: '用户中心'});
	})
	
	onShareTimeline(() => {
		return app.globalData.onShareTimeline({title: '用户中心'});
	})
	
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: linear-gradient(180deg, var(--superadminx-color-light1) 0%, #f5f5f5 100%);padding-bottom:40rpx;}
	.area-top-box{padding: 0 32rpx;position: relative;padding-bottom: 60rpx;background: linear-gradient(25deg,var(--superadminx-color-light1)  0%, #EBFAFF 100%);}
	
	.area-top-box .c-img{width: 114rpx;height: 114rpx;flex-shrink: 0;position: relative;}
	.area-top-box .c-img .img{width: 100%;height: 100%;border-radius: 50%;overflow: hidden;position: relative;z-index: 1;border: 2rpx solid #FCB98E;box-sizing: border-box;}
	.area-top-box .c-info{margin-left: 14rpx;flex: 1;overflow: hidden;display: flex;align-items: center;}
	.area-top-box .c-info .con{width:100%;overflow: hidden;}
	.area-top-box .c-info .con .name{font-size: 42rpx;line-height: 50rpx;height: 50rpx;font-weight: bold;display: flex;align-items: center;}
	.area-top-box .c-info .con .desc{font-size:28rpx;color:#666;padding-top:10rpx;}
</style>
