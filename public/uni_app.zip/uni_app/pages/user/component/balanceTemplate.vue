<template>
	<view class="area-balance">
		<view class="row-list flex">
			<view 
				class="c-item" 
				@click="app.globalData.util.toPages('/pagesWallet/balance/index?field=money', false, true)"
			>
				<text class="num">{{balance.data?.money || 0}}</text>
				<text class="txt">钱包余额</text>
			</view>
			<view 
				class="c-item" 
				@click="app.globalData.util.toPages('/pagesWallet/balance/index?field=integral', false, true)"
			>
				<text class="num">{{balance.data?.integral || 0}}</text>
				<text class="txt">积分余额</text>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow} from '@dcloudio/uni-app';
	import { ref ,onMounted} from 'vue';
	import { useBalanceStore } from '@/store/balance';
	
	const app = getApp();
	const balance = useBalanceStore(); // 余额信息
	
	onMounted(() => {
	})
	
	// 暴露给父组件
	defineExpose({
		refresh: (isLogin) => {
			if (isLogin) {
				balance.update();
			}
		}
	});
</script>

<style lang="scss" scoped>
	.area-balance{background: #ffffff;border-radius: 20rpx;margin-bottom: 20rpx;box-sizing: border-box;padding: 24rpx 0rpx;margin:24rpx 24rpx 0rpx;}
	.area-balance .row-list{padding: 30rpx 12rpx;justify-content: space-around;}
	.area-balance .row-list .c-item{display: flex;flex-direction: column;align-items: center;}
	.area-balance .row-list .c-item .num{font-size: 48rpx;line-height: 60rpx;font-weight: 500;color: #313131;margin-bottom: 20rpx;}
	.area-balance .row-list .c-item .txt{font-size: 32rpx;line-height: 50rpx;font-weight: 400;color: #313131;}
</style>
