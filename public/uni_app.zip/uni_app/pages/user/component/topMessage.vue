<template>
	<view class="top-message-set flex">
		<view 
			class="c1" 
			@click.stop="app.globalData.util.toPages('/pagesUser/message/index', false, true)"
		>
			<wd-badge v-model="messageCount">
				<wd-icon 
					name="notification" 
					size="22px"
					color="#333"
				></wd-icon>
			</wd-badge>
		</view>
		<view 
			class="c1" 
			@click.stop="app.globalData.util.toPages('/pagesUser/setting/index', false, true)"
		>
			<wd-icon 
				name="setting1" 
				size="22px"
				color="#333"
			></wd-icon>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow} from '@dcloudio/uni-app';
	import { ref ,onMounted} from 'vue';
	import { systemNoticeReadApi } from '@/utils/api/systemNoticeRead';
	
	const app = getApp();
	const messageCount = ref(0); // 消息总数
	
	onMounted(() => {
	})
	
	// 获取消息未读条数
	const getReadCount = () => {
		systemNoticeReadApi.getReadCount().then(res => {
			messageCount.value = res.data;
		})
	}
	
	// 暴露给父组件
	defineExpose({
	  refresh: (isLogin) => {
		  if (isLogin) {
			  getReadCount();
		  } else {
			  if (messageCount.value != 0) {
			  			  messageCount.value = 0;
			  }
		  }
	  }
	});
</script>

<style lang="scss" scoped>
	.top-message-set{flex-shrink: 0;margin-left: 10rpx;box-sizing: border-box;padding-top:16rpx;}
	.top-message-set .c1{margin-left: 30rpx;}
	.top-message-set .c1 .c-tb{font-size: 50rpx;color: #000000;font-weight: 500;}
</style>
