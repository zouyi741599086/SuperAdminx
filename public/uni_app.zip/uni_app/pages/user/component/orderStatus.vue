<template>
	<view class="order-status-box">
		<view 
			class="row-title"
			@click="app.globalData.util.toPages('/pagesShop/order/index', false, true)"
		>
			<text class="c-title">我的订单</text>
			<view class="c-right">
				<text class="txt">查看全部</text>
				<wd-icon 
					name="chevron-right" 
					size="20px"
					color="#999999"
				></wd-icon>
			</view>
		</view>
		<view class="row-list">
			<template v-for="(item, index) in orderStatusList" :key="index">
				<view 
					class="c-item"  
					@click="app.globalData.util.toPages(`/pagesShop/order/index?status=${item.status}`, false, true)"
				>
					<view class="item-m">
						<wd-badge v-model="item.num">
							<image :src="`${app.globalData.staticURL}${item.icon}`" mode="aspectFill" class="c-tb"></image>
						</wd-badge>
						<text class="c-txt">{{item.title}}</text>
					</view>
				</view>
			</template>
			
		</view>
		
	</view>
</template>

<script setup>
	import { onLoad, onShow} from '@dcloudio/uni-app';
	import { ref ,onMounted} from 'vue';
	import { shopOrderApi } from '@/utils/api/shopOrder';
	
	const app = getApp();
	// 订单状态
	const orderStatusList = ref([
		{status: 10, title: '待付款', num: 0, icon: '/order1.png'},
		{status: 15, title: '拼团中', num: 0, icon: '/order2.png'},
		{status: 20, title: '待发货', num: 0, icon: '/order3.png'},
		{status: 30, title: '待收货', num: 0, icon: '/order4.png'},
		{status: 'after', title: '售后', num: 0, icon: '/order5.png'},
	])
	
	onMounted(() => {
		uni.$on('updateOrderStatusCount',function(data){
			getOrderStatusCount();
		})
	})
	
	// 各个订单的状态统计
	const getOrderStatusCount = () => {
		shopOrderApi.statusCount().then(res => {
			orderStatusList.value = orderStatusList.value.map(item => {
				return {
					...item,
					num: parseInt(res.data[`status_${item.status}`])
				}
			})
		})
	}
	
	// 暴露给父组件
	defineExpose({
		refresh: (isLogin) => {
			if (isLogin) {
				getOrderStatusCount();
			} else {
				orderStatusList.value = orderStatusList.value.map(item => {
					return {
						...item,
						num: 0
					}
				})
			}
		}
	});
</script>

<style lang="scss" scoped>
	.order-status-box{background: #ffffff;border-radius: 20rpx;margin-bottom: 20rpx;box-sizing: border-box;padding: 24rpx 0rpx;margin:0px 24rpx;}
	.order-status-box .row-title{display: flex;align-items: center;justify-content: space-between;padding: 0 20rpx;margin-bottom: 20rpx;}
	.order-status-box .row-title .c-title{font-size: 34rpx;line-height: 40rpx;font-weight: bold;flex: 1;}
	.order-status-box .row-title .c-right{display: flex;align-items: center;}
	.order-status-box .row-title .c-right .txt{font-size: 30rpx;color: #999999;}
	
	.order-status-box .row-list{display: flex;align-items: center;}
	.order-status-box .row-list .c-item{flex: 1;padding: 20rpx 0rpx;position: relative;display: flex;align-items: center;justify-content: center;}
	.order-status-box .row-list .c-item .item-m{display: flex;flex-direction: column;align-items: center;}
	.order-status-box .row-list .c-item .item-m .c-tb{width: 64rpx;height: 64rpx;}
	.order-status-box .row-list .c-item .item-m .c-txt{font-size: 32rpx;line-height: 40rpx;font-weight: 500;margin-top: 4rpx;}
</style>
