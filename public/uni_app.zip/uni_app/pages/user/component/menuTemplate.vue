<template>
	<view class="area-menu">
		<view class="row-title">
			<text class="c-title">
				<text class="txt">我的服务</text>
			</text>
		</view>
		<view class="row-list">
			<template 
				v-for="(item,index) in menu" 
				:key="index"
			>
				<view class="c-item" v-if="item.title">
					<view 
						class="item" 
						@click="app.globalData.util.toPages(item.url, false, item.needLogin)"
					>
						<image :src="`${app.globalData.staticURL}${item.icon}`" mode="aspectFill" class="c-tb"></image>
						<text class="c-txt">{{item.title}}</text>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow} from '@dcloudio/uni-app';
	import { ref ,onMounted} from 'vue';
	import { useBalanceStore } from '@/store/balance';
	
	const app = getApp();
	// 菜单数据
	const menu = ref([
		{title: '优惠券', icon: `/coupon-ico.png`, url: '/pagesShop/userCoupon/index', needLogin: true},
		{title: '积分订单', icon: `/integral-order.png`, url: '/pagesIntegralShop/order/index', needLogin: true},
		{title: '我的钱包', icon: `/balance-ico.png`, url: '/pagesWallet/balance/index?field=money', needLogin: true},
		{title: '地址管理', icon: `/address.png`, url: '/pagesUser/address/index', needLogin: true},
		{title: '浏览记录', icon: `/footPrint.png`, url: '/pagesShop/footPrint/index', needLogin: true},
		{title: '我的推广', icon: `/children.png`, url: '/pagesShare/index/index', needLogin: true},
		{title: '推广海报', icon: `/poster-ico.png`, url: '/pagesShare/poster/index', needLogin: true},
		{title: '联系客服', icon: `/kefu-ico.png`, url: '/pagesOther/contact/index', needLogin: false},
	]);
	
	onMounted(() => {
	})
	
</script>

<style lang="scss" scoped>
	.area-menu{background: #ffffff;border-radius: 20rpx;margin-bottom: 20rpx;box-sizing: border-box;padding: 24rpx 0rpx;margin:24rpx;}
	.area-menu .row-title{display: flex;align-items: center;justify-content: space-between;padding: 0 20rpx;margin-bottom: 10rpx;}
	.area-menu .row-title .c-title{flex: 1;}
	.area-menu .row-title .c-title .txt{font-size: 34rpx;line-height: 40rpx;font-weight: bold;}
	.area-menu .row-list{display: flex;flex-wrap: wrap;}
	.area-menu .row-list .c-item{width: 25%;padding: 20rpx 0rpx;margin: 0;border-radius: 14rpx;}
	.area-menu .row-list .c-item .item{display: flex;flex-direction: column;align-items: center; background: none;outline: none;padding: 0;}
	.area-menu .row-list .c-item .c-tb{width: 84rpx;height: 84rpx;}
	.area-menu .row-list .c-item .c-txt{font-size: 32rpx;line-height: 40rpx;font-weight: 500;margin-top: 8rpx;}
</style>
