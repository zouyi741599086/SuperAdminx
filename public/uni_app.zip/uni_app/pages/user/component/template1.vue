<template>
	<view class="area-total-count flex">
		<view 
			class="c-item" 
			@click="app.globalData.util.toPages('/pagesShop/userCoupon/index', false, true)"
		>
			<text class="num">{{coupontCount || 0}}</text>
			<text class="txt">优惠券</text>
		</view>
		<view 
			class="c-item" 
			@click="app.globalData.util.toPages('/pagesShop/goodsCollect/index', false, true)"
		>
			<text class="num">{{collectCount || 0}}</text>
			<text class="txt">收藏</text>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow} from '@dcloudio/uni-app';
	import { ref ,onMounted} from 'vue';
	import { shopUserGoodsCollectApi } from '@/utils/api/shopUserGoodsCollect';
	import { shopUserCouponApi } from '@/utils/api/shopUserCoupon';
	
	const app = getApp();
	const coupontCount = ref(0); // 优惠券总数
	const collectCount = ref(0); // 商品收藏总数
	
	onMounted(() => {
	})
	
	// 收藏总数
	const getCollectCount = () => {
		shopUserGoodsCollectApi.getCount().then(res => {
			collectCount.value = res.data;
		})
	}
	
	// 优惠券总数
	const getCoupontCount = () => {
		shopUserCouponApi.getCount().then(res => {
			coupontCount.value = res.data;
		})
	}
	
	// 暴露给父组件
	defineExpose({
		refresh: (isLogin) => {
			if (isLogin) {
				getCollectCount();
				getCoupontCount();
			} else {
				if (coupontCount.value != 0) {
					coupontCount.value = 0;
				}
				if (collectCount.value != 0) {
					collectCount.value = 0;
				}
			}
		}
	});
</script>

<style lang="scss" scoped>
	.area-total-count{justify-content: space-around;padding-bottom:60rpx;}
	.area-total-count .c-item{display: flex;flex-direction: column;align-items: center;color: #313131;}
	.area-total-count .c-item .num{font-size: 44rpx;line-height: 50rpx;font-weight: 500;}
	.area-total-count .c-item .txt{font-size: 30rpx;line-height: 40rpx;font-weight: 500;margin-top: 6rpx;}
</style>
