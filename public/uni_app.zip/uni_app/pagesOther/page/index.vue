<template>
	<view class="page-page">
		<view class="content area-rich-text">
			<mp-html :content="content" />
		</view>
	</view>
</template>

<script setup>
	import { onLoad,onShareAppMessage, onShareTimeline } from '@dcloudio/uni-app';
	import { ref } from 'vue';
	
	const app = getApp()
	
	const name = ref(''); // 参数名称
	const title = ref(); // 页面标题
	const content = ref(''); // 内容
	
	onLoad(options => {
		if (! options.name) {
			app.globalData.util.toast('参数错误');
			setTimeout(()=>{
				app.globalData.util.backPage();
			},1000);
			return;
		}
		name.value = options.name;
		if(options.title){
			uni.setNavigationBarTitle({
				title: options.title
			});
			title.value = options.title;
		}
		
		// 公众号分享
		app.globalData.share();
		
		// 获取单页
		app.globalData.util.getConfig(name.value).then(res => {
			content.value = res.content;
		})
	})
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			title: title.value,
		});
	}) 
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline({
			title: title.value,
		});
	})
</script>

<style>
	page{background: #fff;}
</style>
<style lang="scss" >
	.page-page {min-height: 100vh;background: #fff;font-size: 28rpx;line-height: 1.6;padding: 20rpx;}
	.page-page video{width: 100% !important;}
	
</style>
