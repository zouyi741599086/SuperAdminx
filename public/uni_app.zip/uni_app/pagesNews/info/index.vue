<template>
	<view class="runxue">
		<view class="page-main">
			<view class="row-title">{{data?.title}}</view>
			<view class="row-time">
				<text class="time">{{data?.create_time}}</text>
			</view>
			<view class="area-content">
				<view class="area-rich-text">
					<mp-html :content="data?.content" />
				</view>
			</view>
		</view>
	</view>
	
	<!-- 返回顶部 -->
	<wd-backtop 
		:scrollTop="scrollTop"
		customStyle="background: var(--superadminx-color-light1);color:var(--superadminx-color);"
	></wd-backtop>
</template>

<script setup>
	import { onLoad, onPageScroll, onShareAppMessage, onShareTimeline } from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { newsApi } from '@/utils/api/news';
	
	const app = getApp()
	
	const scrollTop = ref(0);
	const id = ref(); 
	const data = ref(); 
	
	onLoad(options => {
		if (!options.id) {
			app.globalData.util.toast('参数错误');
			return app.globalData.util.backPage();
		}
		id.value = options.id;
		getInfo();
		incPv();
	})
	
	// 窗口滚动的时候
	onPageScroll(e => {
		scrollTop.value = e.scrollTop;
	})
	
	// 获取详情
	const getInfo = () => {
		newsApi.findData({id: id.value}).then(res => {
			data.value = res.data;
			// 公众号分享
			app.globalData.share({
				title: res.data.title
			});
		})
	}
	
	// 增加浏览量
	const incPv = () => {
		newsApi.incPv({id: id.value});
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			title: data.value.title,
		});
	}) 
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline({
			title: data.value.title,
		});
	})
</script>

<style>
	page{background: #fff;}
</style>
<style lang="scss" scoped>
	.runxue{background: #fff;}
	.row-title{font-size: 44rpx;line-height: 60rpx;font-weight: 800;padding: 0 36rpx;padding-top: 10rpx;}
	.row-time{font-size: 24rpx;line-height: 32rpx;font-weight: 500;color: #8995A2;margin-top: 20rpx;display: flex;align-items: center;justify-content: space-between;padding: 0 36rpx;}
	.row-time .c-tb{font-size: 32rpx;line-height: 34rpx;margin-right: 24rpx;}
	.area-content{padding: 30rpx;margin-top: 20rpx;font-size: 28rpx;line-height: 56rpx;}
</style>
