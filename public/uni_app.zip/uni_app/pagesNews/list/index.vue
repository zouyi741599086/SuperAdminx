<template>
	<view class="runxue">
		<wd-tabs 
			v-if="newsClass.length > 1"
			v-model="newsClassActive" 
			custom-class="area-tabs" 
			slidable="always"
			color="var(--superadminx-color)"
			@change="changeNewsClass"
		>
			<wd-tab 
				v-for="(item, index) in newsClass" 
				:key="item.id"
				:name="item.title"
				:title="item.title"
			>	
			</wd-tab>
		</wd-tabs>
		
		<wd-gap bg-color="#f5f5f5" height="52px"></wd-gap>
		<view class="area-list">
			<template v-for="(item,index) in list" :key="item.id">
				<view
					class="row-item"
					hover-class="none"
					:class="{
						'row-item-1': item.img.length == 1,
						'row-item-2': item.img.length == 2,
						'row-item-3': item.img.length > 2
					}"
					@click="app.globalData.util.toPages(`/pagesNews/info/index?id=${item.id}`);"
				>
					<view class="title">
						<view class="t1 line-2">{{item.title}}</view>
						<view 
							class="intro line-1"
							v-if="item.description"
						>{{ item.description}}</view>
						<view class="time">
							<wd-icon 
								name="time" 
								size="14px" 
								color="#999" 
								custom-class="custom-icon"
							></wd-icon>
							{{ item.create_time }}
						</view>
					</view>
					<view class="img" v-if="item.img.length">
						<template v-for="(i,ix) in item.img" :key="ix">
							<image :src="i" mode="aspectFill" class="c-img"></image>
						</template>
					</view>
				</view>
			</template>
			
		</view>
		<area-empty :status="loadingStatus"></area-empty>
		
		<!-- 返回顶部 -->
		<wd-backtop 
			:scrollTop="scrollTop"
			customStyle="background: var(--superadminx-color-light1);color:var(--superadminx-color);"
		></wd-backtop>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onReachBottom, onPageScroll, onShareAppMessage, onShareTimeline } from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { newsApi } from '@/utils/api/news.js';
	import { newsClassApi } from '@/utils/api/newsClass.js';
	import { useRaceSafeList } from '@/utils/useListRequest.js';
	
	const app = getApp();
	
	const scrollTop = ref(0);
	const newsClass = ref([
		{id:1, title: "所有"},
	]);
	const newsClassActive = ref(0); 
	
	const {
		list,
		loadingStatus,
		params,
		refresh,
		loadMore,
	} = useRaceSafeList({
		api: newsApi.getList,  
		params: {       
			news_class_id: newsClass.value[newsClassActive.value].id,
		}  
	});
	
	onLoad(options => {
		getNewsClass();
	})
	onShow(()=>{
		// 公众号分享
		app.globalData.share();
	})
	
	// 窗口滚动的时候
	onPageScroll(e => {
		scrollTop.value = e.scrollTop;
	})
	
	// 获取分类
	const getNewsClass = () => {
		newsClassApi.getChildrenList({id: 1}).then(res => {
			newsClass.value = newsClass.value.concat(res.data);
		})
	}
	
	// 切换分类的时候
	const changeNewsClass = (e) => {
		params.value.news_class_id =  newsClass.value[e.index].id
	}
	
	// 加载下一页
	onReachBottom(() => {
		loadMore();
	})
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			title: '资讯',
		});
	}) 
	onShareTimeline(()=>{
		return app.globalData.onShareTimeline({
			title: '资讯',
		});
	})
</script>

<style>
	page{background: #fff;}
</style>
<style lang="scss" scoped>
	.runxue{background: #fff;width:100%;}
	/*  #ifdef  H5  */
	::v-deep .area-tabs.wd-tabs{top:44px;}
	/*  #endif  */
	/*  #ifdef  MP || APP  */
	::v-deep .area-tabs.wd-tabs{top:0rpx;}
	/*  #endif  */
	::v-deep .area-tabs.wd-tabs{position: fixed;left:0px;z-index: 1;width:100%;height:42px;}
	::v-deep .area-tabs .wd-tabs__nav-item{font-size: 32rpx;font-weight: 600;}
	
	.area-list{width: 100%;box-sizing: border-box;padding: 0rpx 24rpx 0rpx;}
	.area-list .row-item{padding: 30rpx 0rpx;border-bottom: 2rpx solid #eeeeee;}
	
	.area-list .row-item .title{width:100%;}
	.area-list .row-item .title .t1{font-size: 32rpx;font-weight: 600;line-height: 40rpx;color:#000;}
	.area-list .row-item .title .intro{font-size: 26rpx;line-height: 34rpx;color: #666;margin-top: 12rpx;}
	.area-list .row-item .title .time{font-size: 24rpx;color: #999;margin-top: 12rpx;display: flex;align-items: center;}
	::v-deep .area-list .row-item .title .time .custom-icon{margin-right:6rpx;}
	.area-list .row-item .img{display: flex;align-items: center;justify-content: space-between;gap: 0 6rpx;width: 100%;margin-top: 20rpx;}
	.area-list .row-item .img .c-img{flex: 1;max-height:200rpx;}
	.area-list .row-item .img .c-img:first-child{border-top-left-radius: 8rpx;border-bottom-left-radius: 8rpx;}
	.area-list .row-item .img .c-img:last-child{border-top-right-radius: 8rpx;border-bottom-right-radius: 8rpx;}
	
	.area-list .row-item.row-item-1{display: flex;}
	.area-list .row-item.row-item-1 .img{width:200rpx;margin-top:0px;}
	.area-list .row-item.row-item-1 .title{flex:1;padding-right:24rpx;}
</style>
