export default {
	/**
	 * 传入16进制颜色，返回淡化的颜色
	 * @param {string} hex - 16进制颜色值，如 '#fb141c'
	 * @param {number} percent - 亮度增加百分比，默认20
	 * @returns {string} 淡化后的16进制颜色
	 */
	lightenColor(hex, percent = 15) {
		const {
			r,
			g,
			b
		} = this.hexToRgb(hex);
		const [h, s, l] = this.rgbToHsl(r, g, b);
		const newL = Math.min(100, l + percent); // 亮度增加百分比
		const {
			r: newR,
			g: newG,
			b: newB
		} = this.hslToRgb(h, s, newL);
		return this.rgbToHex(newR, newG, newB);
	},

	// 十六进制转RGB
	hexToRgb(hex) {
		// 移除#号
		hex = hex.replace('#', '');

		// 处理3位简写形式
		if (hex.length === 3) {
			hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
		}

		// 解析RGB值
		const r = parseInt(hex.substring(0, 2), 16);
		const g = parseInt(hex.substring(2, 4), 16);
		const b = parseInt(hex.substring(4, 6), 16);

		return {
			r,
			g,
			b
		};
	},

	// RGB转HSL
	rgbToHsl(r, g, b) {
		r /= 255;
		g /= 255;
		b /= 255;

		const max = Math.max(r, g, b);
		const min = Math.min(r, g, b);
		let h, s, l = (max + min) / 2;

		if (max === min) {
			h = s = 0; // 无色
		} else {
			const d = max - min;
			s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

			switch (max) {
				case r:
					h = (g - b) / d + (g < b ? 6 : 0);
					break;
				case g:
					h = (b - r) / d + 2;
					break;
				case b:
					h = (r - g) / d + 4;
					break;
			}
			h /= 6;
		}

		return [h * 360, s * 100, l * 100];
	},

	// HSL转RGB
	hslToRgb(h, s, l) {
		h /= 360;
		s /= 100;
		l /= 100;

		let r, g, b;

		if (s === 0) {
			r = g = b = l; // 无色
		} else {
			const hue2rgb = (p, q, t) => {
				if (t < 0) t += 1;
				if (t > 1) t -= 1;
				if (t < 1 / 6) return p + (q - p) * 6 * t;
				if (t < 1 / 2) return q;
				if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
				return p;
			};

			const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
			const p = 2 * l - q;

			r = hue2rgb(p, q, h + 1 / 3);
			g = hue2rgb(p, q, h);
			b = hue2rgb(p, q, h - 1 / 3);
		}

		return {
			r: Math.round(r * 255),
			g: Math.round(g * 255),
			b: Math.round(b * 255)
		};
	},

	// RGB转十六进制
	rgbToHex(r, g, b) {
		return `#${[r, g, b].map(c => 
			Math.round(c).toString(16).padStart(2, '0')
		).join('')}`;
	}
}