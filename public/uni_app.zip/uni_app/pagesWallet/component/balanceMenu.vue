<template>
	<wd-transition :show="true" name="fade">
		<view class="area-btn">
			<template 
				v-for="(item,index) in list"
				:key="index"
			>
				<view
					class="c-item"
					@click="app.globalData.util.toPages(item.url)"
				>
					<view 
						class="ico"
						:style="color ? `background:${color}` : ''"
					>
						<wd-icon
							:name="item.icon" 
							size="22px"
							color="#fff"
						></wd-icon>
					</view>
					<text class="t1">{{item.title}}</text>
				</view>
			</template>
			
		</view>
	</wd-transition>
</template>

<script setup>
	// 余额的操作菜单
	import { ref, onMounted } from 'vue';
	const app = getApp();
	const props = defineProps({
		// 数据
		list: {
			type: Array,
			default: []
		},
		// 按钮的主色调，不传默认使用主色调
		color: {
			type: String,
			default: ''
		}
	})
	
	function toPages(){
		if (props.data.url) {
			app.globalData.util.toPages(props.data.url)
		}
	}
	
</script>

<style lang="scss" scoped>
	.area-btn{width:auto;display: grid;justify-content: space-between;gap: 20rpx;grid-template-columns: repeat(auto-fit, minmax(140rpx, 1fr));}
	.area-btn .c-item{display: flex;flex-direction: column;justify-content: center;border-radius: 16rpx;padding:20rpx;flex:1;background: #fff;box-shadow: 0px 0px 20rpx 0px #eee;}
	.area-btn .c-item .ico{width:80rpx;height:80rpx;background: var(--superadminx-color);border-radius: 100rpx;display: flex;align-items: center;justify-content: center;margin:0px auto;}
	.area-btn .c-item .t1{font-size:28rpx;text-align: center;padding-top:10rpx;font-weight: 500;}
</style>
