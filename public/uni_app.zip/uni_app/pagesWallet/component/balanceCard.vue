<template>
	<wd-transition :show="true" name="fade">
		<view 
			class="area-top"
			:style="getStyle"
		>
			<view class="top">
				<wd-icon 
					name="wallet" 
					size="22px"
					color="#fff"
				></wd-icon>
				<view class="text">我的{{title}}</view>
			</view>
			<view class="m">
				<view class="t1">可用{{title}}</view>
				<view class="t2"><text class="prefix">{{prefix}}</text>{{balance || 0}}</view>
			</view>
		</view>
	</wd-transition>
</template>

<script setup>
	// 余额卡片
	import { ref, onMounted, computed} from 'vue';
	import util from './util.js';
	
	const app = getApp();
	const props = defineProps({
		// 余额的名称，如积分、余额
		title: {
			type: String,
			default: ''
		},
		// 余额值
		balance: {
			type: [Number, String],
			default: 0
		},
		// 余额的前缀，如 ￥
		prefix: {
			type: String,
			default: '',
		},
		// 卡片的主色调，不传默认使用主色调
		color: {
			type: String,
			default: ''
		}
	})
	// 卡片样式
	const style = ref();
	
	const getStyle = computed(() => {
		if (props.color) {
			let color = util.lightenColor(props.color);
			return `background-image: linear-gradient(to right, ${props.color} 40%, ${color})`;
		}
		return '';
	})
</script>

<style lang="scss" scoped>
	.area-top{width:auto;background-image: linear-gradient(to right, var(--superadminx-color) 40%, var(--superadminx-color-light2));border-radius: 20rpx;box-sizing: border-box;padding:30rpx;}
	.area-top .top{display: flex;align-items: center;}
	.area-top .top .text{flex:1;font-size:36rpx;font-weight: 600; color:#fff;padding-left:16rpx;}
	.area-top .m{overflow: hidden;padding-top:40rpx;}
	.area-top .m .t1{font-size:26rpx;color:#eee;}
	.area-top .m .t2{font-size:56rpx;color:#fff;}
	.area-top .m .t2 .prefix{font-size:40rpx;}
</style>
