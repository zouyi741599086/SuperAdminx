<template>
	<wd-transition :show="true" name="fade">
		<view class="area-list">
			<view class="t">
				<text class="t1">{{title}}明细</text>
				<view class="col-sx">
					<wd-picker 
						:columns="detailsTypeList" 
						v-model="detailsTypeIndex"  
						use-default-slot
						@confirm="changeDetailsType"
					>
						<view class="sx-txt">
							<text class="txt">{{detailsTypeTitle}}</text>
							<wd-icon 
								name="chevron-down" 
								size="20px"
								color="#999"
							></wd-icon>
						</view>
					</wd-picker>
				</view>
			</view>
			<view class="flter">
				<template 
					v-for="(item,index) in actionList"
					:key="index"
				>
					<text 
						class="item"
						:class="{
							on: actionListIndex == index
						}"
						@click="changeActionIndex(index, item.value)"
					>{{item.title}}</text>
				</template>
			</view>
			<view class="m">
				<template v-for="(item,index) in list" :key="index">
					<view class="item-card flex">
						<view class="c-left">
							<view class="r-1">{{ item.title }}</view>
							<view class="r-2">{{item.create_time}}</view>
						</view>
						<view 
							class="c-right"
							:class="{'green': item.change_value > 0}"
						>{{item.change_value > 0 ? '+' : ''}}{{item.change_value}}</view>
					</view>
				</template>
				<area-empty :status="loadingStatus" ></area-empty>
			</view>
		</view>
	</wd-transition>
</template>

<script setup>
	// 余额明细列表
	import { ref, onMounted, computed, onUnmounted} from 'vue';
	import { useRaceSafeList } from '@/utils/useListRequest.js';
	import { balanceDetailsApi } from '@/utils/api/balanceDetails';
	
	const app = getApp();
	const props = defineProps({
		// 余额的名称，如积分、喜豆
		title: {
			type: String,
			default: ''
		},
		// 配置
		fieldConfig: {
			type: Object,
			default: {}
		}
	})
	
	// 增加减少筛选
	const actionList = [
		{
			value: 'all',
			title: '所有'
		},
		{
			value: 'inc',
			title: '增加'
		},
		{
			value: 'dec',
			title: '减少'
		},
	];
	const actionListIndex = ref(0);
	
	// 明细类型筛选
	const detailsTypeIndex = ref();
	const detailsTypeList = computed(()=>{
		let result = [
			{
				value: 'all',
				label: '所有'
			}
		];
		for (let i in props.fieldConfig.details_type) {
			result.push({
				value: i,
				label: props.fieldConfig.details_type[i]
			});
		}
		return result;
	});
	
	const {
		list,
		loadingStatus,
		params,
		refresh,
		loadMore,
		updateParams,
	} = useRaceSafeList({
		api: balanceDetailsApi.getList,  
		params: {       
			balance_type: props.fieldConfig.field,
		},
	});
	
	onMounted(() => {
		// 转账、提现 要触发
		uni.$on('detailsListRefresh', res => {
			refresh();
		})
	})
	
	onUnmounted(() => {
		uni.$off('detailsListRefresh');
	})
	
	// 明细类型筛选改变的时候
	const changeDetailsType = (e) => {
		updateParams({
			details_type: e.value != 'all' ? e.value : ''
		})
	}
	// 筛选项值的文本
	const detailsTypeTitle = computed(() => {
		const item = detailsTypeList.value.find(item => item.value == detailsTypeIndex.value);
		return item ? item.label : '余额类型';
	})
	
	// 增加减少筛选的时候
	const changeActionIndex = (index, value) => {
		actionListIndex.value = index;
		updateParams({
			mon: value
		})
	}
	
	// 暴露方法给父组件
	defineExpose({
		loadMore,
	})
	
</script>

<style lang="scss" scoped>
	.area-list{width:auto;background: #fff;box-sizing: border-box;padding:0px 24rpx 24rpx;border-radius: 20rpx;}
	.area-list .t{width:100%;display: flex;align-items: center;height:80rpx;}
	.area-list .t .t1{font-size:32rpx;font-weight: 600;flex:1;}
	.area-list .t .col-sx{position: relative;font-weight: 500;}
	.area-list .t .col-sx .sx-txt{display: flex;align-items: center;}
	.area-list .t .col-sx .sx-txt .txt{font-size: 26rpx;line-height: 40rpx;color: #999999;display:inline-block;width:200rpx;overflow:hidden;max-height:40rpx;text-overflow:ellipsis;white-space:nowrap;text-align: right;}
	.area-list .t .col-sx .sx-txt .c-tb{margin-left: 10rpx;font-size: 26rpx;}
	
	.area-list .flter{width:100%;padding:10rpx 0rpx 20rpx;}
	.area-list .flter .item{display: inline-block;box-sizing: border-box;border:2rpx solid #ccc;font-size:26rpx;padding:10rpx 30rpx;border-radius: 100rpx;margin-right:20rpx;}
	.area-list .flter .item.on{color: var(--superadminx-color);border-color: var(--superadminx-color);}
	.area-list .flter .item:last-child{margin-right:0rpx;}
	
	.area-list .m{overflow: hidden;}
	.area-list .m .item-card{padding: 24rpx 0rpx;display: flex;align-items: center;justify-content: space-between;border-bottom: 1rpx solid #EEEEEE;}
	.area-list .m .item-card .c-left .r-1{font-size: 28rpx;line-height: 40rpx;font-weight: 500;word-break: break-all;}
	.area-list .m .item-card .c-left .r-2{font-size: 24rpx;line-height: 40rpx;font-weight: 500;color: #999999;}
	.area-list .m .item-card .c-right{font-size: 30rpx;line-height: 40rpx;font-weight: bold;flex-shrink: 0;margin-left: 30rpx;color: red;}
	.area-list .m .item-card .c-right.green{color:green;}
</style>
