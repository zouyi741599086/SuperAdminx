<template>
	<view class="runxue">
		<wd-gap height="24rpx" bg-color="#f5f5f5"></wd-gap>
		<view class="area-list">
			<view 
				class="list-item" 
				v-for="(item,index) in list" 
				:key="index" 
				@click="app.globalData.util.toPages(`/pagesWallet/withdraw/list/info/index?id=${item.id}`)"
			>
				<view class="col-left">
					<view class="r-title">
						<text class="txt">{{item.bank_title}}</text>
					</view>
					<view class="r-time">
						<text class="txt">{{item.bank_number}}</text>
					</view>
				</view>
				<view class="col-center">
					<view class="r-value">
						<text class="t">￥</text>
						<text class="txt">{{item.money}}</text>
					</view>
					<view class="r-status">
						<text 
							class="txt"
							:style="{'color':setStaColor(item.status)}"
						>{{statusToTxt(item.status)}}</text>
					</view>
				</view>
				<view class="col-right">
					<wd-icon
						name="chevron-right" 
						size="18px"
						color="#999"
					></wd-icon>
				</view>
			</view>
		</view>
		<area-empty :status="loadingStatus" ></area-empty>
			
	</view>
</template>

<script setup>
	import { onLoad, onShow, onReachBottom, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { balanceWithdrawApi } from '@/utils/api/balanceWithdraw';
	import { useRaceSafeList } from '@/utils/useListRequest.js';
	
	const app = getApp();
	
	const {
		list,
		loadingStatus,
		params,
		refresh,
		loadMore,
		updateParams,
	} = useRaceSafeList({
		api: balanceWithdrawApi.getList,  
		autoLoad: false,
	});
	
	onLoad((option) => {
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			refresh();
		}
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 每个状态的颜色
	const setStaColor = (status) => {
		if(status == 2){
			return '#DBA842';
		}
		if(status == 4 || status == 8){
			return '#53B324';
		}
		if(status == 6 || status == 10){
			return '#F51818';
		}
	}
	
	// 每个状态的文字
	const statusToTxt = (status) => {
		switch(parseInt(status)){
			case 2:
				return '审核中';
			case 4:
				return '审核通过';
			case 6:
				return '审核拒绝';
			case 7:
				return '打款中';
			case 8:
				return '已打款';
			case 10:
				return '打款失败';
		}
	}
	
	// 加载下一页
	onReachBottom(() => {
		loadMore();
	})
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #fff;}
</style>
<style lang="scss" scoped>
	.runxue{background: #fff;}
	.area-list{background: #ffffff;padding: 10rpx 24rpx 0rpx;}
	.area-list .list-item{height: 128rpx;display: flex;align-items: center;line-height: 40rpx;border-bottom: 1rpx solid #eeeeee;}
	.area-list .list-item .col-left{flex:1;}
	.area-list .list-item .r-title .txt{font-size: 30rpx;font-weight: 600;}
	.area-list .list-item .r-time .txt{font-size: 26rpx;color: #999999;font-weight: 500;}
	.area-list .list-item .col-center{text-align: right;padding-right:10rpx;}
	.area-list .list-item .col-center .r-status .txt{font-size: 26rpx;}
	.area-list .list-item .col-center .r-value{}
	.area-list .list-item .col-center .r-value .t{font-size:24rpx;color:var(--superadminx-color);}
	.area-list .list-item .col-center .r-value .txt{font-size: 32rpx;font-weight: bold;color:var(--superadminx-color);}
	
</style>
