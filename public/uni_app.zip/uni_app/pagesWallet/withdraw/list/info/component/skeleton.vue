<template>
	<view style="padding:30rpx 30rpx;">
		<wd-skeleton 
			:row-col="[
				[
					{width: '100%', height: '720rpx'}
				],
				[
					{width: '100%', height: '260rpx'}
				],
			]"
			animation="gradient"
		/>
	</view>
</template>

<script>
</script>

<style>
</style>