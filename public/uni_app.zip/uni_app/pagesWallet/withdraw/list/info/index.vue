<template>
	<template v-if="! data.id">
		<skeleton />
	</template>
	<view class="runxue" v-else>
		<view class="area-box">
			<view class="row-money flex">
				<text class="txt">{{data.money}}</text>
			</view>
			<view class="row-item">
				<text class="title">提现单号</text>
				<text 
					class="content" 
					@click="copyContent(data.orderno)"
				>{{data.orderno}} | 复制</text>
			</view>
			<view class="row-item">
				<text class="title">申请时间</text>
				<text class="content">{{data.create_time}}</text>
			</view>
			<view class="row-item" v-if="data.shouxufei && data.shouxufei > 0">
				<text class="title">扣除手续费</text>
				<text class="content t-bold">￥{{data.shouxufei}}</text>
			</view>
			<view class="row-item">
				<text class="title">实际到账</text>
				<text class="content t-bold">￥{{data.on_money}}</text>
			</view>
			<view class="row-item">
				<text class="title">提现姓名</text>
				<text class="content">{{data.bank_name}}</text>
			</view>
			<view class="row-item">
				<text class="title">提现银行</text>
				<text class="content">{{data.bank_title}}/{{data.bank_number}}</text>
			</view>
		</view>
		
		<view class="area-box">
			<view class="row-item">
				<text class="title">提现状态</text>
				<text 
					class="content" 
					:style="{'color':setStaColor(data.status)}"
				>{{statusToTxt(data.status)}}</text>
			</view>
			<view class="row-item" v-if="data.status > 1 && data.audit_time">
				<text class="title">审核时间</text>
				<text class="content">{{data.audit_time}}</text>
			</view>
			<view class="row-item" v-if="data.pay_time">
				<text class="title">打款时间</text>
				<text class="content">{{data.pay_time}}</text>
			</view>
			<view class="row-item" v-if="data.reason">
				<text class="title">错误原因</text>
				<text class="content">{{data.reason}}</text>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref, reactive } from 'vue';
	import { balanceWithdrawApi } from '@/utils/api/balanceWithdraw';
	import skeleton from './component/skeleton.vue';
	
	const app = getApp();
	const id = ref('');
	const data = ref({});
	
	onLoad((option) => {
		if (!option.id) {
			app.globalData.util.toast('参数错误');
			return app.globalData.util.backPage();
		}
		id.value = option.id;
		
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			getData();
		}
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share({
			path: "/"
		});
	})
	
	// 获取详情
	const getData = () => {
		balanceWithdrawApi.findData({
			id: id.value,
		}).then(res => {
			data.value = res.data;
		}).catch(res => {
			app.globalData.util.backPage();
		})
	}
	//复制内容
	const copyContent = (text) => {
		uni.setClipboardData({
			data: text,
			showToast: true,
			success: () => {
				app.globalData.util.toast('复制成功');
			}
		});
	}
	
	// 获取状态颜色
	const setStaColor = (status) => {
		if(status == 2){
			return '#DBA842';
		}
		if(status == 4 || status == 8){
			return '#53B324';
		}
		if(status == 6 || status == 10){
			return '#F51818';
		}
	}
	
	// 获取状态文字
	const statusToTxt = (status) => {
		switch(parseInt(status)){
			case 2:
				return '审核中';
			case 4:
				return '审核通过';
			case 6:
				return '审核拒绝';
			case 7:
				return '打款中';
			case 8:
				return '已打款';
			case 10:
				return '打款失败';
		}
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;padding: 24rpx 24rpx 20rpx;}
	.area-box{border-radius: 20rpx;background: #ffffff;margin-bottom: 20rpx;padding: 20rpx 20rpx;box-sizing: border-box;overflow: hidden;}
	.area-box .row-money{height: 200rpx;justify-content: center;border-bottom: 1rpx solid #E5E5E5;margin-bottom: 30rpx;align-items: center;}
	.area-box .row-money .txt{font-size: 80rpx;line-height: 108rpx;color: var(--superadminx-color);}
	.area-box .row-item{display: flex;align-items: center; justify-content: space-between;position: relative;padding:10rpx 0rpx;}
	.area-box .row-item .title{width: 144rpx;line-height: 54rpx;font-size: 28rpx;color: #666666;flex-shrink: 0;}
	.area-box .row-item .content{flex: 1; line-height: 40rpx;font-size: 28rpx;color: #000000;display: flex;align-items: center;}
	
	.area-box .row-item .t-bold{font-weight: bold;color: var(--superadminx-color);}
	
</style>
C