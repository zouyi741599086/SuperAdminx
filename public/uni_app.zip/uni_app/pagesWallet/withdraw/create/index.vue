<template>
	<view class="runxue">
		<wd-navbar
			title="提现"
			left-arrow
			@click-left="app.globalData.util.backPage();"
			fixed
			custom-style="background-color: transparent;"
			:bordered="false"
			safeAreaInsetTop
		></wd-navbar>
		
		<view 
			class="area-top"
			:style="`padding-top:${systemInfo.data?.safeAreaInsets?.top + 44}px`"
		>
			<view class="row-balance">
				<text class="num">{{balance.data[fieldConfig.field] || 0}}</text>
				<text class="txt">{{fieldConfig.title}}</text>
			</view>
		</view>
		<view class="page-main">
			<view class="area-box1">
				<view class="row-item">
					<text class="col-left">提现银行</text>
					<wd-picker 
						:columns="balanceWithdrawConfig.bank_list" 
						label="" 
						v-model="formData.bank_title" 
						custom-class="wd-picker-cs"
					/>
				</view>
				<view class="row-item">
					<text class="col-left">银行卡号</text>
					<input 
						type="number" 
						class="c-input" 
						v-model="formData.bank_number" 
						placeholder="银行卡号"
					/>
				</view>
				<view class="row-item">
					<text class="col-left">姓名</text>
					<input 
						type="text" 
						class="c-input" 
						v-model="formData.bank_name" 
						placeholder="姓名"
					/>
				</view>
				<view class="row-item r-btn-none">
					<text class="col-left">{{fieldConfig.title}}提现</text>
				</view>
				<view class="row-input">
					<text class="c-left">{{fieldConfig.field == 'money' ? '￥' : ''}}</text>
					<input 
						type="digit" 
						class="c-input" 
						v-model="formData.money" 
						placeholder="请输入..."
					/>
					<text 
						class="c-btn" 
						@click="formData.money = balance.data[fieldConfig.field]"
					>全部提现</text>
				</view>
				<view class="r-tips">
					<text class="txt">最小提现：{{balanceWithdrawConfig.min_money}}</text>
				</view>
			</view>
			
			<view class="row-tips">
				<text class="txt">提现将扣除{{balanceWithdrawConfig.shouxufei_bili}}%手续费，最迟两天到账~</text>
			</view>
			<view class="row-btn" @click="toSubmit()">
				<wd-button 
				block
				size="large"
				:disabled="submitting"
				>提交</wd-button>
			</view>
			
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onUnload,  onShareAppMessage} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { useSystemInfoStore } from '@/store/systemInfo.js';
	import { balanceApi } from '@/utils/api/balance';
	import { balanceWithdrawApi } from '@/utils/api/balanceWithdraw';
	import { useBalanceStore } from '@/store/balance.js';
	import { useSubmit } from '@/utils/useSubmit.js';
	
	const app = getApp();
	const systemInfo = useSystemInfoStore();
	const balance = useBalanceStore();
	
	const field = ref(); // 余额的类型
	const fieldConfig = ref({}); // 余额类型的配置
	
	const balanceWithdrawConfig = ref({}); // 提现配置
	const formData = ref({}); // form数据
	const { submitting, handleSubmit } = useSubmit(); // 表单提交钩子
	
	onLoad((option) => {
		if(!option.field) {
			app.globalData.util.toast('参数错误');
			return app.globalData.util.backPage();
		}
		field.value = option.field;
		
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			getFieldConfig();
			getBalanceWithdrawConfig();
			getLastInfo();
		}
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 获取余额的配置
	const getFieldConfig = () => {
		balanceApi.getBalanceConfig({
			field: field.value,
		}).then(res => {
			fieldConfig.value = res.data;
			
			// 设置标题
			uni.setNavigationBarTitle({
				title: `我的${res.data.title}`
			})
		})
	}
	
	// 获取提现配置
	const getBalanceWithdrawConfig = () => {
		app.globalData.util.getConfig('balance_withdraw_config').then(res => {
			// 提现银行转数组
			res.bank_list = res.bank_list.split('\n').filter(item => item.trim() !== '');
			balanceWithdrawConfig.value = res;
		})
	}
	
	// 获取最后一次提现详情，自动填写到表单上
	const getLastInfo = () => {
		balanceWithdrawApi.getLastInfo().then(res => {
			formData.value = {
				bank_title: res.data.bank_title,
				bank_number: res.data.bank_number,
				bank_name: res.data.bank_name
			};
		})
	}
	
	// 提交
	const toSubmit = () => {
		if(! formData.value.bank_title){
			return app.globalData.util.toast('请选择提现银行~');
		}
		if(! formData.value.bank_number){
			return app.globalData.util.toast('请输入银行卡号~');
		}
		if(! formData.value.bank_name){
			return app.globalData.util.toast('请输入姓名~');
		}
		if(! formData.value.money){
			return app.globalData.util.toast('请输入提现金额~');
		}
		if(parseFloat(formData.value.money) > balance.data.money){
			return app.globalData.util.toast('余额不足~');
		}
		handleSubmit(() => {
			return balanceWithdrawApi.create({
				...formData.value,
				balance_type: fieldConfig.value.field
			}).then(res => {
				app.globalData.util.toast(res.message);
				balance.update();
				uni.$emit('detailsListRefresh'); // 刷新明细列表
				app.globalData.util.backPage();
				return res;
			})
		})
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background-color: #f5f5f5;background-image: linear-gradient(to bottom, var(--superadminx-color-light1), #f5f5f5);padding-bottom:24rpx;}
	.area-top{overflow: hidden;}
	.area-top .row-balance{display: flex;flex-direction: column;align-items: center;justify-content: center;padding:60rpx 0rpx;}
	.area-top .row-balance .num{font-size: 44rpx;line-height: 50rpx;font-weight: bold;}
	.area-top .row-balance .txt{font-size: 28rpx;line-height: 40rpx;font-weight: 500;}
	
	.page-main{position: relative;padding: 0 24rpx;}
	.area-box1{background: #ffffff;border-radius: 16rpx;padding: 0rpx 24rpx;position: relative;}
	.area-box1 .row-item{height: 120rpx;display: flex;align-items: center;justify-content: space-between;border-bottom: 1rpx solid #eee;}
	.area-box1 .row-item .col-left{font-size: 30rpx;font-weight: 500;flex-shrink: 0;margin-right: 20rpx;}
	
	::v-deep .area-box1 .row-item .wd-picker-cs{flex:1;--wot-picker-toolbar-finish-color: var(--superadminx-color);}
	::v-deep .area-box1 .row-item .wd-picker-cs .is-hover{background: none;}
	::v-deep .area-box1 .row-item .wd-picker-cs .wd-cell__wrapper{padding-right:0px;}
	::v-deep .area-box1 .row-item .wd-picker-cs .wd-cell__wrapper .wd-cell__value {font-size:30rpx;text-align: right;}
	::v-deep .area-box1 .row-item .wd-picker-cs .wd-picker__cell--placeholder .wd-cell__value{color:#999;}
	
	.area-box1 .row-item .c-input{flex: 1;height: 80rpx;line-height: 80rpx;font-size: 30rpx;text-align: right;}
	.area-box1 .row-item.r-btn-none{border-bottom: none;}
	
	.area-box1 .row-input{display: flex;align-items: center;padding-bottom: 20rpx;border-bottom: 1rpx solid #eee;}
	.area-box1 .row-input .c-left{font-size: 40rpx;flex-shrink: 0;margin-right: 20rpx;}
	.area-box1 .row-input .c-input{flex: 1;font-size: 36rpx;line-height: 60rpx;height: 60rpx;margin-right: 30rpx;}
	.area-box1 .row-input .c-btn{font-size: 30rpx;flex-shrink: 0;color: var(--superadminx-color-dark1);}
	.area-box1 .r-tips{height: 80rpx;display: flex;align-items: center}
	.area-box1 .r-tips .txt{font-size: 24rpx;color: #666666;}
	
	.row-btn{margin-top: 50rpx;width: 100%;}
	.row-tips{margin-top: 30rpx;text-align: center;}
	.row-tips .txt{font-size: 24rpx;line-height: 32rpx;color: #999999;}
	
</style>
