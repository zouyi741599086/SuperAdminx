<template>
	<view class="runxue">
		<balanceCard
			title="余额"
			:balance="balance.data.money"
			prefix="￥"
		/>
		<wd-gap height="24rpx"></wd-gap>
		<view class="top-warp">
			<view class="input-m">
				<text class="t1">￥</text>
				<input 
					type="digit" 
					v-model="money"
					placeholder="输入充值金额..."
					class="input"
				/>
			</view>
			<view class="select-m">
				<view class="t1">
					<text class="txt">或选择充值金额</text>
				</view>
				<view class="m">
					<template
						v-for="(item,index) in balanceTopUp?.top_list"
						:key="index"
					>
						<view 
							class="item" 
							hover-class="item-on"
							@click="money = item.money"
						>
							<text class="money">{{item.money}}</text>
							<text class="unit">元</text>
						</view>
					</template>
					
				</view>
			</view>
		</view>
		
		<wd-gap height="24rpx"></wd-gap>
		<wd-button 
			block 
			size="large"
			@click="toPay"
		>充值</wd-button>
		
		<wd-gap height="24rpx"></wd-gap>
		<wd-card 
			title="充值说明"
			custom-class="custom-card"
			custom-content-class="custom-content-class"
		>
			<mp-html :content="balanceTopUp?.content" />
		</wd-card>
	</view>
	
	<!-- 支付方式 -->
	<pay 
		ref="payRef"
		:api="balanceTopUpApi.pay"
		:params="{
			money: money
		}"
		:payType="['wechat', 'alipay']"
		:paySuccess="() => {
			uni.$emit('detailsListRefresh'); // 刷新明细列表
			app.globalData.util.backPage();
		}"
	/>
	
</template>

<script setup>
	import { onLoad, onShow, onReachBottom, onPageScroll, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import balanceCard from '../component/balanceCard.vue';
	import { useBalanceStore } from '@/store/balance.js';
	import { balanceTopUpApi } from '@/utils/api/balanceTopUp';
	
	const app = getApp();
	const balance = useBalanceStore();
	
	const money = ref(); // 充值金额
	const balanceTopUp = ref(); // 充值设置
	const payRef = ref(); // 支付
	
	onLoad((option) => {
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			app.globalData.util.getConfig('balance_top_up').then(res => {
				// 充值已关闭
				if (res.on == false) {
					app.globalData.util.toast('非法请求~');
					return app.globalData.util.backPage();
				}
				balanceTopUp.value = res;
			})
		}
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 充值
	const toPay = () => {
		if (! money.value) {
			return app.globalData.util.toast('请输入或选择充值金额~');
		}
		if (parseFloat(money.value) <= 0) {
			return app.globalData.util.toast('请输入正确的充值金额~');
		}
		payRef.value.changeShow();
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
	
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;overflow: hidden;padding:24rpx;}
	
	.top-warp{background: #fff;border-radius: 20rpx;box-sizing: border-box;padding:30rpx;}
	.top-warp .input-m{display: flex;align-items: center;border-bottom:2rpx solid #eee;box-sizing: border-box;padding-bottom:20rpx;}
	.top-warp .input-m .t{font-size:32rpx;}
	.top-warp .input-m .input{flex:1;margin-left:20rpx;height:80rpx;font-size:40rpx;color: var(--superadminx-color);font-weight: 500;}
	.top-warp .select-m{padding:24rpx 0rpx;}
	.top-warp .select-m .t1 .txt{font-size:24rpx;color:#999;}
	.top-warp .select-m .m{display: grid; grid-template-columns: repeat(3, 1fr);gap: 20rpx;padding-top:20rpx;}
	.top-warp .select-m .m .item{box-sizing: border-box;border:2rpx solid #eee;border-radius: 20rpx;text-align: center;height:100rpx;line-height:100rpx;}
	.top-warp .select-m .m .item-on{background: #f9f9f9;}
	.top-warp .select-m .m .item .money{font-size:32rpx;font-weight: 600;}
	.top-warp .select-m .m .item .unit{font-size:26rpx;}
	
	::v-deep .wd-card.custom-card{margin:0rpx;border-radius: 20rpx;}
	::v-deep .custom-content-class{padding-bottom:32rpx;}
</style>
