<template>
	<template v-if="! fieldConfig.field">
		<skeleton />
	</template>
	<view class="runxue" v-else>
		<view class="area-box1">
			<view class="row-item">
				<text class="txt">转账用户</text>
			</view>
			<view class="row-input">
				<view class="c-left">
					<wd-icon 
						name="mobile" 
						size="22px"
						color="#333"
					></wd-icon>
				</view>
				<input 
					type="number" 
					class="c-input" 
					v-model="telKeywords" 
					placeholder="对方手机号..."
					maxlength="11"
					@confirm="searchUser"
				/>
				<text class="c-btn" @click="searchUser">搜索</text>
			</view>
			<view class="user" v-if="user?.id">
				<image 
					:src="user.img" 
					mode="aspectFill" 
					class="img"
				></image>
				<view class="c-info">
					<view class="con">
						<view class="name">
							<text class="txt">{{user.name}}</text>
						</view>
						<view class="desc">
							<text class="txt">{{user.tel}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="area-box1">
			<view class="row-item">
				<text class="txt">转账{{fieldConfig.title}}</text>
				<text class="t1">{{fieldConfig.title}} {{balance.data[fieldConfig.field]}}</text>
			</view>
			<view class="row-input">
				<text class="c-left">{{fieldConfig.field == 'money' ? '￥' : ''}}</text>
				<input 
					type="digit" 
					class="c-input" 
					v-model="money" 
					placeholder="请输入..."
				/>
				<text 
					class="c-btn" 
					@click="money = balance.data[fieldConfig.field]"
				>全部{{fieldConfig.title}}</text>
			</view>
		</view>
		
		<view class="row-btn" @click="toSubmit()">
			<wd-button 
				block 
				size="large"
				:disabled="submitting"
			>确认转账</wd-button>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onUnload,  onShareAppMessage} from '@dcloudio/uni-app';
	import { ref, watch } from 'vue';
	import { balanceApi } from '@/utils/api/balance.js';
	import { userApi } from '@/utils/api/user.js';
	import { useSubmit } from '@/utils/useSubmit.js';
	import { useBalanceStore } from '@/store/balance.js';
	import skeleton from './component/skeleton.vue';
	
	const app = getApp();
	const balance = useBalanceStore();
	
	const field = ref(); // 余额的类型
	const fieldConfig = ref({}); // 余额类型的配置
	
	const telKeywords = ref(); // 搜索用户的关键字
	const user = ref(); // 搜索到的用户
	
	const money = ref(); // 转账金额
	
	const { submitting, handleSubmit } = useSubmit(); // 表单提交钩子
	
	onLoad((option) => {
		if (!option.field) {
			app.globalData.util.toast('参数错误');
			return app.globalData.util.backPage();
		}
		field.value = option.field;
		
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			getFieldConfig();
		}
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 获取余额的配置
	const getFieldConfig = () => {
		balanceApi.getBalanceConfig({
			field: field.value,
		}).then(res => {
			if( res.data.turn == false) {
				app.globalData.util.toast('该余额不支持转账');
				return app.globalData.util.backPage();
			}
			fieldConfig.value = res.data;
			
			// 设置标题
			uni.setNavigationBarTitle({
				title: `${res.data.title}转账`
			})
		})
	}
	
	// 搜索词改变的时候
	watch(()=> telKeywords.value, (newVal) => {
		if (newVal.length == 11 && app.globalData.util.checkTel(newVal)) {
			searchUser();
		}
	})
	
	// 搜索用户
	const searchUser = () => {
		if (!telKeywords.value) {
			return app.globalData.util.toast('请输入手机号');
		}
		if (! app.globalData.util.checkTel(telKeywords.value)) {
			return app.globalData.util.toast('请输入正确的手机号');
		}
		
		userApi.searchUser({
			tel: telKeywords.value
		}).then(res => {
			user.value = res.data;
		}).catch(err => {
			user.value = {};
		})
	}
	
	// 提交
	const toSubmit = () => {
		if (! user.value?.id) {
			return app.globalData.util.toast('请搜索转账用户~');
		}
		if(! money.value){
			return app.globalData.util.toast('请输入转账金额~');
		}
		const _money = parseFloat(money.value);
		if (_money <= 0) {
			return app.globalData.util.toast('请输入正确的转账金额~');
		}
		if (_money > balance.data[fieldConfig.value.field]) {
			return app.globalData.util.toast(`${fieldConfig.value.title}不足~`);
		}
		
		app.globalData.util.modal(`确定转账给${user.value.tel}吗？`).then(() => {
			handleSubmit(() => {
				return balanceApi.turn({
					to_user_id: user.value.id,
					value: _money,
					balance_type: fieldConfig.value.field
				}).then(res => {
					app.globalData.util.toast(res.message);
					balance.update();// 更新余额
					uni.$emit('detailsListRefresh'); // 刷新明细列表
					setTimeout(() => {
						app.globalData.util.backPage();
					}, 1500);
					return res;
				})
			})
		})
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;overflow:hidden;position: relative;padding: 24rpx;}

	.area-box1{background: #ffffff;border-radius: 16rpx;padding: 0rpx 24rpx;position: relative;margin-bottom:24rpx;overflow: hidden;}
	.area-box1 .row-item{height: 120rpx;display: flex;align-items: center;justify-content: space-between;;}
	.area-box1 .row-item .txt{font-size: 32rpx;font-weight: 600}
	.area-box1 .row-item .t1{font-size:28rpx;font-weight: normal;color:#666;}

	.area-box1 .row-input{display: flex;align-items: center;padding-bottom: 40rpx;}
	.area-box1 .row-input .c-left{font-size: 40rpx;flex-shrink: 0;margin-right: 20rpx;}
	.area-box1 .row-input .c-input{flex: 1;font-size: 32rpx;line-height: 60rpx;height: 60rpx;margin-right: 30rpx;}
	.area-box1 .row-input .c-btn{font-size: 30rpx;flex-shrink: 0;color: var(--superadminx-color-dark1);}
	
	.area-box1 .user{width:auto;overflow: hidden;display: flex;padding:20rpx;background:#f9f9f9;border-radius: 20rpx;margin-bottom:20rpx;}
	.area-box1 .user .img{width:100rpx;height:100rpx;border-radius: 120rpx;}
	.area-box1 .user .c-info{flex:1;padding-left:20rpx;display: flex;align-items: center;}
	.area-box1 .user .c-info .con{overflow: hidden;}
	.area-box1 .user .c-info .con .name .txt{font-size:38rpx;font-weight: 600;}
	.area-box1 .user .c-info .con .desc{padding-top:10rpx;}
	.area-box1 .user .c-info .con .desc .txt{font-size:26rpx;color:#666;}


	.row-btn{margin-top: 50rpx;width: 100%;}

	
</style>
