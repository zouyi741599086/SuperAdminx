<template>
	<view style="padding:30rpx 30rpx;">
		<wd-skeleton 
			:row-col="[
				[
					{width: '100%', height: '260rpx'}
				],
				[
					{width: '100%', height: '150rpx'}
				]
			]"
			animation="gradient"
		/>
		<wd-skeleton 
			theme="text" 
			:customStyle="{
				marginTop: '40rpx'
			}"
			animation="gradient"
		/>
		<wd-skeleton
			theme="text" 
			:customStyle="{
				marginTop: '40rpx'
			}"
			animation="gradient"
		/>
		<wd-skeleton
			theme="text" 
			:customStyle="{
				marginTop: '40rpx'
			}"
			animation="gradient"
		/>
		<wd-skeleton
			theme="text" 
			:customStyle="{
				marginTop: '40rpx'
			}"
			animation="gradient"
		/>
	</view>
</template>

<script>
</script>

<style>
</style>