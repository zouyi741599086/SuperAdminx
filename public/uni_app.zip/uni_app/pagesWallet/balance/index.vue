<template>
	<template v-if="! fieldConfig.field">
		<skeleton />
	</template>
	<view class="runxue" v-else>
		<balanceCard
			:title="fieldConfig.title"
			:balance="balance.data[fieldConfig.field]"
			:prefix="fieldConfig.field == 'money' ? '￥' : ''"
			:color="fieldConfig.color"
		/>
		
		<wd-gap height="24rpx"></wd-gap>
		<balanceMenu
			:list="getMenu"
			:color="fieldConfig.color"
		/>
		
		<wd-gap height="24rpx"></wd-gap>
		<template v-if="fieldConfig.details">
			<detailList
				:title="fieldConfig.title"
				:fieldConfig="fieldConfig"
				ref="detailsListRef"
			/>
		</template>
	</view>
	
	<!-- 回到顶部 -->
	<wd-backtop 
		:scrollTop="scrollTop"
		customStyle="background: var(--superadminx-color-light1);color:var(--superadminx-color);"
	></wd-backtop>
</template>

<script setup>
	import { onLoad, onShow, onReachBottom, onPageScroll, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref, computed} from 'vue';
	import balanceCard from '../component/balanceCard.vue';
	import balanceMenu from '../component/balanceMenu.vue';
	import detailList from '../component/detailList.vue';
	import skeleton from './component/skeleton.vue';
	import { balanceApi } from '@/utils/api/balance.js';
	import { configApi } from '@/utils/api/config.js';
	import { useBalanceStore } from '@/store/balance.js';
	
	const app = getApp();
	const balance = useBalanceStore();
	const scrollTop = ref(0);
	
	const field = ref(); // 余额的类型
	const fieldConfig = ref({}); // 余额类型的配置
	const detailsListRef = ref(); // 明细列表实例
	
	const balanceTopUp = ref(); // 充值设置
	
	onLoad((option) => {
		if(!option.field) {
			app.globalData.util.toast('参数错误');
			return app.globalData.util.backPage();
		}
		field.value = option.field;
		
		// 登录后
		if (app.globalData.util.isLogin(1,true)) {
			getFieldConfig();
		}
		
		app.globalData.util.getConfig('balance_top_up').then(res => {
			balanceTopUp.value = res;
		})
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	onPageScroll(e => {
		scrollTop.value = e.scrollTop;
	})
	
	// 获取余额的配置
	const getFieldConfig = () => {
		balanceApi.getBalanceConfig({
			field: field.value,
		}).then(res => {
			fieldConfig.value = res.data;
			
			// 设置标题
			uni.setNavigationBarTitle({
				title: `我的${res.data.title}`
			})
		})
	}
	
	// 获取操作的菜单
	const getMenu = computed(() => {
		let menu = [];
		if (fieldConfig.value.field == 'money') {
			
			// 是否开启了充值
			if (balanceTopUp.value?.on == true) {
				menu.push({
					title: '充值',
					icon: 'upload',
					url: '/pagesWallet/topUp/index'
				});
			}
		}
		if (fieldConfig.value.field == 'integral') {
			menu = [
				{
					title: '签到',
					icon: 'calendar',
					url: '/pagesUser/signIn/index'
				},
				{
					title: '积分商城',
					icon: 'cart',
					url: '/pagesIntegralShop/index/index'
				},
				{
					title: '积分订单',
					icon: 'list',
					url: '/pagesIntegralShop/order/index'
				},
			];
		}
		
		// 是否允许提现
		if (fieldConfig.value.withdraw) {
			menu.push({
				title: '提现记录',
				icon: 'list',
				url: '/pagesWallet/withdraw/list/index'
			},
			{
				title: '申请提现',
				icon: 'money-circle',
				url: `/pagesWallet/withdraw/create/index?field=${fieldConfig.value.field}`
			})
		}
		
		// 是否允许转账
		if (fieldConfig.value.turn) {
			menu.push({
				title: `${fieldConfig.value.title}转账`,
				icon: 'translate-bold',
				url: `/pagesWallet/turn/index?field=${fieldConfig.value.field}`
			});
		}
		return menu;
	})
	
	// 加载下一页
	onReachBottom(() => {
		detailsListRef.value.loadMore();
	})
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;overflow: hidden;padding:24rpx;}
	
</style>
