<template>
	<view class="runxue">
		<view class="page-main">
			<view class="area-box">
				<view 
					class="row-info" 
					@click="app.globalData.util.toPages(`/pagesUser/setting/info/index`)"
				>
					<text class="c-title">个人信息</text>
					<wd-icon 
						name="chevron-right" 
						size="22px"
						color="#999"
					></wd-icon>
				</view>
			</view>
			<view class="area-box">
				<template 
					v-for="(item,index) in menu"
					:key="index"
				>
					<view
						class="row-info" 
						@click="app.globalData.util.toPages(item.url)"
					>
						<text class="c-title">{{item.title}}</text>
						<wd-icon
							name="chevron-right" 
							size="22px"
							color="#999"
						></wd-icon>
					</view>
				</template>
			</view>
			
			<!--  #ifdef  MP -->
			<view class="area-box">
				<view class="row-info">
					<button class="full-width-btn" open-type="openSetting">权限设置</button>
					<wd-icon
						name="chevron-right" 
						size="22px"
						color="#999"
					></wd-icon>
				</view>
				<view class="row-info">
					<button class="full-width-btn" open-type="feedback">反馈与投诉</button>
					<wd-icon
						name="chevron-right" 
						size="22px"
						color="#999"
					></wd-icon>
				</view>
			</view>
			<!--  #endif -->
			
			<view class="area-box">
				<view class="row-info">
					<text class="c-title">个性化消息推</text>
					<view class="col-right">
						<template v-if="user.data?.id">
							<wd-switch
								v-model="user.data.UserInfo.message_push" 
								active-value="1" 
								inactive-value="2" 
								:before-change="messagePushChange"
								active-color="var(--superadminx-color)"
							/>
						</template>
					</view>
				</view>
			</view>
			
		</view>
		
		<view class="page-bottom">
			<view class="row-btn" @click="logout()">
				<wd-button block size="large">退出登录</wd-button>
			</view>
			<view class="row-info">
				<text class="txt">当前版本：{{systemInfo.data?.appVersion}}</text>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref, computed} from 'vue';
	import {useUserStore} from '@/store/user.js';
	import { useBalanceStore } from '@/store/balance.js';
	import {useSystemInfoStore} from '@/store/systemInfo.js';
	import { userApi } from '@/utils/api/user';
	
	const app = getApp();
	const user = useUserStore();
	const systemInfo = useSystemInfoStore();
	
	const menu = ref([
		{
			title: '用户协议',
			url: '/pagesOther/page/index?title=用户协议&name=user_agreement'
		},
		{
			title: '用户协议',
			url: '/pagesOther/page/index?title=用户协议&name=user_agreement'
		},
		{
			title: '关于我们',
			url: '/pagesOther/page/index?title=关于我们&name=about'
		},
		{
			title: '联系我们',
			url: '/pagesOther/contact/index'
		},
		
	])
	
	onLoad((option) => {
		// 登录后
		app.globalData.util.isLogin(1,true);
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 退出登录
	const logout = () => {
		app.globalData.util.modal('确定退出登录吗？').then(res => {
			uni.removeStorageSync('token');
			user.data = {};
			
			const balance = useBalanceStore();
			balance.data = {};
			
			app.globalData.util.toPages('/pages/index/index', 'all');
		})
	}
	
	// 个性化消息推送开关
	const messagePushChange = ({ value, resolve }) => {
		userApi.updateInfo({
			action: 'message_push',
			message_push: value
		},true).then(res => {
			resolve(true);
			user.update();
		}).catch(res => {
			resolve(false);
		})
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
	
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;}
	.page-main{padding: 20rpx 0rpx;}
	.area-box{background: #ffffff;position: relative;margin-bottom:20rpx}
	.area-box .row-info{padding: 0 24rpx;height: 100rpx;width: 100%;box-sizing: border-box;display: flex;align-items: center;justify-content: space-between;border-bottom: 1px solid #ebebeb;}
	.area-box .row-info .c-title{font-size: 28rpx;font-weight: 500;color: #000;}
	.area-box .row-info:last-of-type{border-bottom: none;}
	
	.page-bottom{position:fixed;left:0px;box-sizing: border-box;padding:0px 40rpx;width:100%;bottom:calc(env(safe-area-inset-bottom) + 12px);}
	.page-bottom .row-btn{width: 100%;}
	.page-bottom .row-info{width:100%;text-align: center;padding-top:20rpx;}
	.page-bottom .row-info .txt{font-size:24rpx;color:#666;}
	
	// 按钮样式
	.area-box .row-info .full-width-btn {
	    margin: 0;
	    padding: 0;
	    background: transparent;
	    border: none;
	    font-size: 28rpx; // 文字大小
	    color: #000;
	    width: 100%;
	    height: 100%;
	    text-align: left;
	    flex: 1;
	    display: flex; // 使用 flex 布局实现垂直居中
	    align-items: center; // 文字垂直居中
	    line-height: 1.2; // 调整行高（避免文字截断）
		font-weight: 500;
	    // 去除微信按钮默认样式
	    &::after {
	      border: none;
	    }
	  }
</style>
