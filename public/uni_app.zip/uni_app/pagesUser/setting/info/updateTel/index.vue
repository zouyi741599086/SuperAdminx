<template>
	<view class="runxue">
		<view class="area-box">
			<view class="row-item">
				<wd-icon 
					name="mobile" 
					size="22px"
					color="#666"
				></wd-icon>
				<input 
					type="number" 
					v-model="form.tel" 
					class="c-input" 
					placeholder="请输入..." 
					placeholder-class="input-placeholder"
				/>
			</view>
			<view class="row-item">
				<wd-icon 
					name="secured" 
					size="22px"
					color="#666"
				></wd-icon>
				<input 
					type="number" 
					v-model="form.code" 
					class="c-input" 
					placeholder="请输入..." 
					placeholder-class="input-placeholder"
				/>
				<text 
					class="btn-yzm" 
					v-if="!showTime" 
					@click="toGetCode()"
				>获取验证码</text>
				<view class="btn-yzm btn-yzm2" v-else>
					<wd-count-down 
						:time="time" 
						format="sss后再次获取" 
						@finish="showTime = false" 
						custom-class="count-down-class"
					/>
				</view>
			</view>
		</view>
		
		<view class="form-btn">
			<button
				class="btn"
				@click="toSubmit()"
				:disabled="submitting"
			>保存修改</button>
		</view>
			
	</view>
</template>

<script setup>
	import { onLoad, onShow, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { userApi } from '@/utils/api/user.js';
	import { useUserStore } from '@/store/user';
	import { useSubmit } from '@/utils/useSubmit.js';
	
	const app = getApp();
	
	const user = useUserStore();
	const form = ref({});
	const showTime = ref(false);
	const time = ref(60 * 1000);
	const { submitting, handleSubmit } = useSubmit(); // 表单提交钩子
	
	onLoad((option) => {
		// 登录后
		app.globalData.util.isLogin(1,true);
	})
	onShow(() => {
		// 公众号分享
		app.globalData.share();
	})
	
	// 获取验证码
	const toGetCode = () => {
		if(!form.value.tel){
			return app.globalData.util.toast('请输入手机号'); 
		}
		if(!app.globalData.util.checkTel(form.value.tel)){
			return app.globalData.util.toast('请输入正确的手机号');
		}
		// 获取验证码接口
		userApi.getUpdateTelCode({
			tel: form.value.tel,
		}).then(res => {
			showTime.value = true;
			time.value = 60 * 1000;
			app.globalData.util.toast(res.message);
		})
		
	}
	
	// 提交
	const toSubmit = () => {
		if(!form.value.tel){
			return app.globalData.util.toast('请输入手机号'); 
		}
		if(!app.globalData.util.checkTel(form.value.tel)){
			return app.globalData.util.toast('请输入正确的手机号');
		}
		if(!form.value.code){
			return app.globalData.util.toast('请输入验证码'); 
		}
		handleSubmit(() => {
			return userApi.updateInfo({
				action: 'tel',
				...form.value
			}).then(res => {
				user.data.tel = form.value.tel;
				app.globalData.util.toast('修改成功');
				setTimeout(() => {
					app.globalData.util.backPage();
				}, 1500)
				return res;
			})
		})
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
	
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;padding: 30rpx 0rpx;}
	.area-box .row-item{height: 96rpx;background: #ffffff; display: flex;align-items: center;box-sizing: border-box;overflow: hidden;padding: 0 30rpx;border-bottom:2rpx solid #f5f5f5;}
	.area-box .row-item .c-input{flex: 1;font-size: 30rpx;color: #000;margin-left:20rpx;}
	.area-box .row-item .input-placeholder{font-weight: 500;color: #999999;}
	.area-box .row-item .btn-yzm{margin-left: 20rpx;height: 52rpx;line-height: 52rpx;text-align: center;border-radius: 30rpx;background: var(--superadminx-color-light1);color: var(--superadminx-color);font-size: 24rpx;margin-left: 30rpx;padding:0px 20rpx;display: flex;align-items: center;}
	.area-box .row-item .btn-yzm2{background: #C5C7D2;color: #999999;}
	.area-box .row-item :deep(.wd-count-down){color: #999999;}
	.form-btn{width: auto;box-sizing: border-box;margin:50rpx 30rpx;}
	.form-btn .btn{width: 100%;height: 80rpx;line-height: 80rpx;border-radius: 45rpx;text-align: center;background: var(--superadminx-color);color: #ffffff;font-size: 30rpx;font-weight: bold;}
	
</style>
