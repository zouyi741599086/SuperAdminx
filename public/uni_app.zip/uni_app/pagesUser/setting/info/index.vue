<template>
	<view class="runxue">
		<view class="area-box">
			<view class="row-header">
				<button 
					class="c-img flex" 
					<!--  #ifdef MP -->
					type="default" 
					open-type="chooseAvatar" 
					@chooseavatar="updateImg"
					hover-class="none"
					<!--  #endif -->
					<!--  #ifndef MP -->
					@click="updateImg"
					<!--  #endif -->
				>
					<image 
						:src="user.data?.img || `${app.globalData.staticURL}/tb-tx.png`" 
						mode="aspectFill" 
					></image>
					<text class="r-txt">点击修改头像</text>
				</button>
			</view>
			<view class="row-info">
				<text class="c-title">昵称</text>
				<view class="col-right">
					<input 
						class="c-input" 
						:value="user.data?.name" 
						type="nickname" 
						@blur="updateUserName" 
						@confirm="updateUserName" 
						placeholder="设置"
					/>
					<wd-icon
						name="chevron-right" 
						size="22px"
						color="#999"
					></wd-icon>
				</view>
			</view>
			
			<view class="row-info">
				<text class="c-title">手机号码</text>
				<button 
					class="col-right" 
					<!--  #ifdef MP -->
					open-type="getPhoneNumber" 
					@getphonenumber="getPhoneNumber"
					<!--  #endif -->
					<!--  #ifndef MP -->
					@click="app.globalData.util.toPages('/pagesUser/setting/info/updateTel/index')"
					<!--  #endif -->
				>
					<view class="c-input">
						<wd-text 
							:text="user.data?.tel || '设置'" 
							mode="phone" 
							:format="true" 
							color="#000000"
						></wd-text>
					</view>
					<wd-icon
						name="chevron-right" 
						size="22px"
						color="#999"
					></wd-icon>
				</button>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad, onShow, onShareAppMessage} from '@dcloudio/uni-app';
	import { ref } from 'vue';
	import { useUserStore } from '@/store/user';
	import { userApi } from '@/utils/api/user';
	import { fileApi } from '@/utils/api/file';
	import { loginApi } from '@/utils/api/login';
	
	const app = getApp();
	const user = useUserStore();
	
	onLoad((option) => {
		// 登录后
		app.globalData.util.isLogin(1,true);
	})
	onShow(() => {
		app.globalData.util.isLogin();
		// 公众号分享
		app.globalData.share();
	})
	
	// 更新头像
	const updateImg = (e) => {
		// 小程序的时候
		// #ifdef MP
			if (! app.globalData.util.isUploadFile(e.detail.avatarUrl)) {
				return app.globalData.util.toast('只能上传图片');
			}
			fileApi.upload(
				e.detail.avatarUrl,
				'file',
				{width:200,height:200},
				true
			).then(res => {
				updateInfoApi('img',res.data.file)
			})
		// #endif
		
		// 非小程序的时候
		// #ifndef MP
			uni.chooseImage({
				count: 1,
				sizeType: ['compressed'],
				crop: {
					width: 200,
					height: 200
				},
				success: function (res) {
					if (! app.globalData.util.isUploadFile(res.tempFiles[0].name)) {
						return app.globalData.util.toast('只能上传图片');
					}
					fileApi.upload(
						res.tempFilePaths[0],
						'file',
						{width:200,height:200},
						true
					).then(res => {
						updateInfoApi('img',res.data.file)
					})
				}
			});
		// #endif
	}
	
	// 更新昵称
	const updateUserName = (e) => {
		const { value } = e.detail;
		if (! value) {
			return app.globalData.util.toast('修改内容不能为空');
		}

		if (value == user.data.name) return;
		updateInfoApi('name', value);
	}
	
	// 小程序的时候更新手机号
	// #ifdef MP
	const getPhoneNumber = (e) => {
		if (e.detail.errMsg == 'getPhoneNumber:ok') {
			loginApi.mpWeixinGetPhoneNumber({
				code: e.detail?.code
			}).then((res) => {
				updateInfoApi('tel', res.data);
			});
		} else {
			app.globalData.util.toast('手机号码授权失败');
		}
	}
	// #endif
	
	// 更新用户资料api
	const updateInfoApi = (key, val) => {
		let params = {
			action: key
		}
		params[key] = val;
		userApi.updateInfo(params).then(res => {
			user.data[key] = val;
			app.globalData.util.toast('修改成功');
		})
	}
	
	onShareAppMessage(()=>{
		return app.globalData.onShareAppMessage({
			path: 'pages/index/index',
		});
	})
</script>

<style>
	page{background: #f5f5f5;min-height:100%;}
</style>
<style lang="scss" scoped>
	.runxue{background: #f5f5f5;padding: 20rpx 0rpx;}
	.area-box{background: #ffffff;position: relative;}
	.area-box .row-header{height: 308rpx;display: flex;align-items: center;justify-content: center;}
	.area-box .row-header .c-img{display: flex;align-items: center;justify-content: center;flex-direction: column;}
	.area-box .row-header .c-img image{width: 120rpx;height: 120rpx;border-radius: 50%;border: 2rpx solid #ffffff;box-sizing: border-box;display: block;box-shadow: 4rpx 4rpx 6rpx 6rpx #F4F7FB;}
	.area-box .row-header .r-txt{font-size: 22rpx;line-height: 32rpx;margin-top: 10rpx;color: #999999;text-align: center;}
	
	.area-box .row-info{padding: 0 24rpx;height: 100rpx;width: 100%;box-sizing: border-box;display: flex;align-items: center;justify-content: space-between;border-top: 2rpx solid #ebebeb;}
	.area-box .row-info .c-title{font-size: 28rpx;font-weight: 500;}
	.area-box .row-info .tb-right{font-size: 24rpx;color: #999999;margin-left: 10rpx;}
	.area-box .row-info .c-ct{font-size: 30rpx;}
	.area-box .row-info2{height: auto;padding: 16rpx 24rpx;}
	.area-box .row-info .col-right{display: flex;align-items: center;flex: 1;justify-content: flex-end;font-size: 28rpx;}
	.area-box .row-info .col-right .c-img{width: 112rpx;height: 112rpx;border-radius: 50%;display: block;border: none;background: transparent;}
	.area-box .row-info .col-right .c-img image{width: 100%;height: 100%;}
	.area-box .row-info .col-right .c-input{flex: 1;height: 60rpx;line-height: 60rpx;text-align: right;}
	
	button{background: transparent;padding: 0;margin: 0;}
	button::after{border: none;}
</style>
