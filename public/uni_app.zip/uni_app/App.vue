<script>
	import util from './utils/util.js'
	import config from './utils/config.js';
	import { useUserStore } from '@/store/user';
	import { useBalanceStore } from '@/store/balance';
	import { useSystemInfoStore } from '@/store/systemInfo';
	
	// #ifdef H5
	// 公众号的分享配置
	import wechatJsSdkUtil from '@/utils/wechatJsSdkUtil.js';
	// 公众号获取openid
	import wechatMpOpenidUtil from './utils/wechatMpOpenidUtil.js';
	// #endif
	
	// #ifdef MP
	// 小程序的分享配置
	import wechatMiniShareUtil from '@/utils/wechatMiniShareUtil.js';
	// 小程序更新
	import wechatMiniUpdateUtil from './utils/wechatMiniUpdateUtil.js';
	// #endif
	
	// #ifdef APP-PLUS
	// 安卓权限申请
	import permissionListener from "@/uni_modules/c-permission-listener";       // 插件市场导入方法 https://ext.dcloud.net.cn/plugin?id=22675
	import permissionEnums from "@/utils/permissionEnums.js";   // 导入权限说明枚举类
	
	// app更新检测
	import APPUpdate from '@/uni_modules/zhouWei-APPUpdate/js_sdk/appUpdate';
	// #endif
	
	export default {
		globalData: {
			util,
			staticURL: process.env.NODE_ENV === 'development' ? config.devStaticURL : config.staticURL,
			
			// 公众号的分享配置
			share: (shareConfig = {}) => {
				// #ifdef H5
				if (util.isWeChatBrowser()) {
					wechatJsSdkUtil.share(shareConfig);
				}
				// #endif
			},

			// 小程序的分享配置
			onShareAppMessage: (shareConfig = {}) => {
				// #ifdef MP
				return wechatMiniShareUtil.onShareAppMessage(shareConfig);
				// #endif
			},
			// 小程序的分享配置
			onShareTimeline: (shareConfig = {}) => {
				// #ifdef MP
				return wechatMiniShareUtil.onShareTimeline(shareConfig);
				// #endif
			}
			
		},

		onLaunch: function() {
			
			// app更新检测
			// #ifdef APP
			APPUpdate();
			// #endif
			
		},
		onShow: function() {
			// 获取系统信息
			const systemInfo = useSystemInfoStore();
			systemInfo.data = uni.getSystemInfoSync();
			
			// 用户自动登录，非微信自动登录
			const user = useUserStore();
			user.update().then(res => {
				// 登录成功后刷新余额
				const balance = useBalanceStore();
				balance.update();
			}).catch(err => {
				//console.log(err)
			})
			
			// 公众号的时候获取openid
			// #ifdef H5
			if (util.isWeChatBrowser()) {
				wechatMpOpenidUtil.init();
			}
			// #endif
			
			// 小程序更新
			// #ifdef MP
			wechatMiniUpdateUtil.update();
			// #endif
			
			// 安卓权限申请
			// #ifdef APP
			// 唤起权限会触发onHide，所以listenerFunc须在onShow生命周期调用
			permissionListener && permissionListener.listenerFunc(permissionEnums);
			// #endif
			
		},
		onHide: function() {
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import url("@/app.scss");
</style>