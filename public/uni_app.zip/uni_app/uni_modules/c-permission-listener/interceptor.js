/**
 * @description 添加拦截器，拦截特殊api
 */
const apiList = {
	location: ["getLocation", "chooseLocation"],
	bluetooth: ["openBluetoothAdapter"]
}
export const permissionInterceptor = () => {
	const main = plus.android.runtimeMainActivity();
	const Intent = plus.android.importClass("android.content.Intent");
	apiList.location.forEach(apiName => {
		uni.addInterceptor(apiName, {
			invoke() {
				// 必须放在这边，否则无法知道最新状态
				const { locationEnabled } = uni.getSystemSetting();
			    if (!locationEnabled) {
			    	uni.showModal({
			    		title: "温馨提示",
			    		content: "请开启手机定位功能以使用此服务！",
			    		success: (res) => {
			    			if (res.confirm) {
			    				const locationIntent = new Intent('android.settings.LOCATION_SOURCE_SETTINGS');
			    				main.startActivity(locationIntent);
			    			}
			    		}
			    	})
					return false;
			    }
				return true;
			}
		})
	})
	apiList.bluetooth.forEach(apiName => {
		uni.addInterceptor(apiName, {
			invoke() {
				// 必须放在这边，否则无法知道最新状态
				const { bluetoothEnabled } = uni.getSystemSetting();
				if (!bluetoothEnabled) {
					uni.showModal({
						title: "温馨提示",
						content: "请开启手机蓝牙功能以使用此服务",
						success: (res) => {
							if (res.confirm) {
								const bluetoothIntent = new Intent('android.settings.BLUETOOTH_SETTINGS');
								main.startActivity(bluetoothIntent);
							}
						}
					})
					return false;
				}
				return true;
			}
		})
	})
}

/**
 * @description 移除拦截器
 */
export const removeInterceptor = () => {
	let removeList = [];
	Object.values(apiList).forEach(item => {
		removeList.push(...item);
	});
	removeList.forEach(apiName => {
		uni.removeInterceptor(apiName);
	})
}