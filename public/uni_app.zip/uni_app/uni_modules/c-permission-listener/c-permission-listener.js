/**
 * @author cai
 * @time 2024-08-12 14:29
 * uni.createRequestPermissionListener()
 * 文档地址：https://uniapp.dcloud.net.cn/api/system/create-request-permission-listener.html
 * 注意：HBuilderX (4.0+) android 平台支持；HBuilderX 4.01 Vue2项目需要使用自定义基座测试监听权限申请的功能，标准基座暂不支持测试。
 */
// #ifndef APP
export default null;
// #endif
// #ifdef APP
import { permissionInterceptor, removeInterceptor } from "./interceptor.js"
import { drawView, hideView } from "./explain.js";
const { osName, romName } = uni.getSystemInfoSync();

const HARMONY_STORAGE_KEY = "harmony-refuse-permission";	// 鸿蒙被拒绝权限列表的缓存key;
const MODAL = {
	title: "温馨提示",
	singleContent: (name, explain) => `开启${name}权限后，才能${explain}`,
	multipleContent: (name) => `开启${name}权限后，才能使用相关功能`,
}

/**
 * @description 获取权限名称，例如android.permission.CAMERA，获取CAMERA
 * @param {String} fullPermissionName，权限全称，例如：android.permission.CAMERA
 * @return {String} 例如：CAMERA
 */
const getPermissionName = (fullPermissionName) => {
	const nameSplitList = fullPermissionName.split(".");
	return nameSplitList[nameSplitList.length - 1];
}

/**
 * @description 获取权限状态
 * @param {String} permissionName
 * @return {Boolean} true表示当前权限允许
 */
const checkPermissionStatus = (permissionName) => {
	const permission = `android.permission.${permissionName}`;
	const MainActivity = plus.android.runtimeMainActivity();
	const status = MainActivity.checkSelfPermission(permission);
	return status == 0;
}

/**
 * @description 获取鸿蒙被拒绝的权限列表
 * @return {Array}
 */
const getHarmonyRefuseList = () => {
	return uni.getStorageSync(HARMONY_STORAGE_KEY) || [];
}

/**
 * @description 更新鸿蒙被拒绝的权限列表
 */
const updateHarmonyRefuseList = (status, name) => {
	/**
	 * @description 非纯血鸿蒙（可以安装apk），权限被永久拒绝，官方还是走onConfirm回调（是个bug）
	 * 纯血鸿蒙不会返回romName
	 */
	if (romName !== "HarmonyOS") return;
	const harmonyRefusePermission = this.getHarmonyRefuseList();
	// 权限状态不是允许的
	if (!status && !harmonyRefusePermission.includes(name)) {
		harmonyRefusePermission.push(name);
	}
	// 权限状态是允许的
	if (status && harmonyRefusePermission.includes(name)) {
		const spliceIndex = harmonyRefusePermission.findIndex(item => item === name);
		harmonyRefusePermission.splice(spliceIndex, 1);
	}
	uni.setStorageSync(HARMONY_STORAGE_KEY, harmonyRefusePermission);
}

class State {
	constructor(arg) {
		this.enums = null;	// 权限枚举，包含名称和说明
		this.drawing = false;	// 是否正在绘画顶部说明
		this.canRunListener = true;	// 是否可以执行所有监听方法
		this.showModaling = false;	// 是否正在显示showModal
		this.hasConfirm = false;	// 是否有权限弹窗（触发permissionListener.onConfirm这个回调）
		this.nameList = [];		// 没有授权的权限列表
	}
	// 重置部分值，onRequest函数下调用
	resetPart() {
		this.showModaling = false;
		this.hasConfirm = false;
		this.nameList = [];
	}
	// 添加还未授权的权限名称
	addPermissionName(name) {
		const hasName = this.nameList.some(item => item.name === name);
		// 列表没有当前权限才需要添加进去
		if (!hasName) {
			this.nameList.unshift({name, status: null});
		}
	}
	// 改变权限列表对应权限的状态
	changePermissionStatus(name) {
		const status = checkPermissionStatus(name);
		const nameIndex = this.nameList.findIndex(item => item.name === name);
		if (nameIndex > -1) {
			this.nameList[nameIndex].status = status;
		}
	}
	// 获取权限和权限说明
	getNameExplain() {
		if (!this.enums) return { name: "", explain: "" };
		let nameSet = new Set();
		let explainSet = new Set();
		this.nameList.forEach(item => {
			const currentKey = Object.keys(this.enums).find(key => key.includes(item.name));
			if (currentKey) {
				const permissionEnum = this.enums[currentKey];
				const { name, explain } = permissionEnum;
				nameSet.add(name);
				explainSet.add(explain);
			}
		})
		return {
			name: Array.from(nameSet).join("、"),
			explain: Array.from(explainSet).join("；"),
		}
	}
}

class Manager {
	constructor(arg) {
		this.listener = null;
		this.state = new State();
		// 是安卓平台，同时有uni.createRequestPermissionListener这个api
		if (osName === "android" && uni.createRequestPermissionListener) {
			this.listener = uni.createRequestPermissionListener();
		}
	}
	// 展示顶部权限说明
	showExplainView() {
		/**
		 * @description 满足条件绘画顶部权限说明
		 * this.state.nameList.length > 0，没有授权的列表大于0
		 * this.state.hasConfirm，有触发onConfirm
		 * getNameExplain().name，权限名称有值
		 */
		const { name, explain } = this.state.getNameExplain();
		if (this.state.nameList.length > 0 && this.state.hasConfirm && name) {
			drawView({
				title: `${name}权限使用说明`,
				content: MODAL.singleContent(name, explain)
			}, {
				start: () => {
					// 开始绘画
					this.state.drawing = true;
				},
				success: () => {
					// 绘画结束
					this.state.drawing = false;
				}
			});
		}
	}
	// 前往设置页
	goToSetting() {
		const { name, explain } = this.state.getNameExplain();
		this.state.showModaling = true;
		let content = "";
		content = this.state.nameList.length > 1 ?
		MODAL.multipleContent(name) :
		MODAL.multipleContent(name, explain);
		uni.showModal({
			content,
			showCancel: true,
			title: MODAL.title,
			confirmText: "去设置",
			success: (res) => {
				if (res.confirm) {
					uni.openAppAuthorizeSetting();
				}
			}
		})
	}
	// 监听申请系统权限
	onRequest() {
		this.listener.onRequest((permissions) => {
			console.log("【c-permission-listener】onRequest回调：", permissions);
			this.state.resetPart();
			(permissions || []).forEach(item => {
				const name = getPermissionName(item);
				// 当前权限不是允许的
				if (!checkPermissionStatus(name)) {
					this.state.addPermissionName(name);
				}
			})
		});
	}
	// 监听弹出系统权限授权框
	onConfirm() {
		this.listener.onConfirm((permissions) => {
			console.log("【c-permission-listener】onConfirm回调：", permissions);
			let nameList = [];
			(permissions || []).forEach(item => {
				const name = getPermissionName(item);
				nameList.push(name);
			})
			/**
			 * @description 非纯血鸿蒙（可以安装apk），权限被永久拒绝，官方还是走onConfirm回调（是个bug）
			 * 纯血鸿蒙不会返回romName
			 */
			// onConfirm回调的权限列表都包含在harmonyRefusePermission里面
			const hasAll = nameList.every(item => getHarmonyRefuseList().includes(item));
			this.state.hasConfirm = !(romName === "HarmonyOS" && hasAll);
			// 显示顶部蒙层说明
			this.showExplainView();
		});
	}
	// 监听权限申请完成
	onComplete() {
		this.listener.onComplete((permissions) => {
			console.log("【c-permission-listener】onComplete回调：", permissions);
			if (permissions.length === 0) return;
			let harmonyRefusePermission = uni.getStorageSync(HARMONY_STORAGE_KEY) || [];
			permissions.forEach(item => {
				const permission = getPermissionName(item);
				// 改变权限列表对应权限的状态
				this.state.changePermissionStatus(permission);
				updateHarmonyRefuseList(permission);
			})
			// 所有权限是否都拒绝，item.status === false不能改为!item.status，因为item.status默认为null
			const allRefused = this.state.nameList.every(item => item.status === false);
			/**
			 * @description 所有权限都被拒绝后模态窗提示用户去设置
			 * allRefused，所有权限都被拒绝
			 * !this.state.showModaling，当前没有模态窗
			 * !this.state.hasConfirm，没有触发permissionListener.onConfirm回调
			 * this.state.getNameExplain().name，权限名称有值
			 * this.state.nameList.length > 0，没有授权的列表大于0
			 */
			if (allRefused && !this.state.showModaling && !this.state.hasConfirm && this.state.getNameExplain().name && this.state.nameList.length > 0) {
				this.goToSetting();
				return;
			}
			hideView();
			this.state.drawing = false;
		});
	}
	/**
	 * @description 监听权限方法
	 * @example
		const permissionParams = {
			"ACCESS_COARSE_LOCATION": {		// 取android.permission.ACCESS_COARSE_LOCATION后面那个
				name: "定位",	// 当前权限是什么名称
				explain: "展示附近店铺、填写收货地址等相关功能"		// 权限说明
			},
		}
	 */
	start(permissionEnums) {
		if (!permissionEnums) return;
		this.state.enums = permissionEnums;
		if (this.state.canRunListener && this.listener) {
			console.log("【c-permission-listener】执行start");
			this.state.canRunListener = false;
			// 监听申请系统权限
			this.onRequest();
			// 监听弹出系统权限授权框
			this.onConfirm();
			// 监听权限申请完成
			this.onComplete();
		}
	}
	// 取消所有监听方法
	stop() {
		// drawing为true，正在绘画顶部
		if (this.listener && !this.state.drawing) {
			console.log("【c-permission-listener】执行stop");
			this.state.canRunListener = true;
			hideView();
			this.state.drawing = false;
			this.listener.stop();
		}
	}
}

let exportObj = null;
if (osName === 'android' && uni.createRequestPermissionListener) {
	const manager = new Manager();
	exportObj = {
		permissionInterceptor,	// 监听定位和蓝牙
		removeInterceptor,	// 移除监听
		listenerFunc: (permissionEnums) => manager.start(permissionEnums),	// 监听唤起权限，显示蒙层
		stopFunc: () => manager.stop()	// 取消监听唤起权限
	}
} else {
	exportObj = null;
}
export default exportObj;
// #endif