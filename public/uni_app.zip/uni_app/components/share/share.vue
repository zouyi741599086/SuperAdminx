<template>
	<wd-root-portal>
		<wd-popup 
			v-model="show" 
			position="bottom"
			:safe-area-inset-bottom="safeAreaInsetBottom"
			:z-index="999" 
			custom-style="background:none"
		>
			<view class="share-list">
				<view class="ms">
					<view class="m">
						<template
							v-for="(item,index) in getShareList"
							:key="index"
						>
							<view class="item" @click="handleItem(item)">
								<image :src="`${app.globalData.staticURL}${item.img}`" class="img"></image>
								<view class="title">
									<text class="txt">{{item.title}}</text>
								</view>
								<template v-if="item.type == 'mp-wechat'">
									<button 
									class="wechat-share"
									open-type="share"
									style="width:100%;"
									></button>
								</template>
							</view>
						</template>
					</view>
					<view class="b">
						<wd-button 
							type="info" 
							block 
							size="large"
							@click="changeShow"
						>取消</wd-button>
					</view>
				</view>
			</view>
		</wd-popup>
		<!-- 微信浏览器内右上角提示 分享 -->
		<wd-overlay 
			:show="wxUpRightShow"
			@click="wxUpRightShow = false"
			:zIndex="999"
		>
			<image :src="`${app.globalData.staticURL}/share-up-right-img.png`" class="wx-up-right-img"></image>
		</wd-overlay>
	</wd-root-portal>
</template>

<script setup>
	// 分享弹窗
	import { ref, onMounted, computed} from 'vue';
	import { useUserStore } from '@/store/user';
	import wechatJsSdkUtil from '@/utils/wechatJsSdkUtil.js';
	
	const app = getApp();
	
	const props = defineProps({
		// 是否开启底部安全距离
		safeAreaInsetBottom: {
			type: Boolean,
			default: true
		},
		// 接管点击分享海报执行的函数
		posterFun: {
			type: Function,
			default: null
		}
	})
	
	const user = useUserStore();
	const show = ref(false); // 弹窗开关
	const wxUpRightShow = ref(false); // 微信内右上角提示分享弹窗开关
	const shareAppConfig = ref(); // app分享的配置
	
	onMounted(() => {
	})
	
	// 分享的按钮
	const getShareList = computed(() => {
		let list = [
			// #ifdef APP
				// app的分享
				{
				    img: '/share-wechat.png',
				    title: '微信好友',
					type: 'app-wechat'
				},
				{
				    img: '/share-group.png',
				    title: '微信朋友圈',
					type: 'app-time-line'
				},
				{
				    img: '/share-img.png',
				    title: '分享海报',
					type: 'poster'
				},
			// #endif
			
			// #ifdef MP
				// 小程序的分享
				{
					img: '/share-wechat.png',
					title: '微信好友',
					type: 'mp-wechat'
				},
				{
					img: '/share-img.png',
					title: '分享海报',
					type: 'poster'
				},
			// #endif
			
			// #ifndef APP || MP
				// 网页的分享
				{
					img: '/share-img.png',
					title: '分享海报',
					type: 'poster'
				},
				{
					img: '/share-copy-url.png',
					title: '复制连接',
					type: 'copy-url'
				},
			// #endif
		]; 
		
		// 如果是微信浏览器，则增加右上角分享
		if (app.globalData.util.isWeChatBrowser()) {
			list.push({
				img: '/share-up-right.png',
				title: '直接分享',
				type: 'up-right'
			})
		}
		return list;
	})
	
	// 弹窗开关
	const changeShow = () => {
		// 如果是app，则获取app分享的配置
		// #ifdef APP
			if (! shareAppConfig.value) {
				app.globalData.util.getConfig('share_app_config').then(res => {
					shareAppConfig.value = res;
				})
			}
		// #endif
		
		show.value = ! show.value;
	}
	
	// 点击分享的时候
	const handleItem = (item) => {
		changeShow();
		// 分享海报
		if (item.type == 'poster') {
			// 是否有接管
			if (props.posterFun) {
				props.posterFun();
			} else if (app.globalData.util.isLogin(2)) {
				app.globalData.util.toPages('/pagesShare/poster/index');
			}
		}
		
		// 复制链接
		if (item.type == 'copy-url') {
			uni.setClipboardData({
				data: wechatJsSdkUtil.getH5ShareUrl(user.data.id || ''),
				success: () => {
					app.globalData.util.toast('已复制');
				}
			})
		}
		
		// 微信浏览器内右上角分享
		if (item.type == 'up-right') {
			wxUpRightShow.value = true;
		}
		
		// 如果是app分享到微信好友
		if (item.type == 'app-wechat') {
			uni.share({
				provider:'weixin',
				type: 0, // 分享图文
				title: shareAppConfig.value.share_title,
				scene: 'WXSceneSession', // 分享到微信聊天界面
				summary: '',
				href: `${shareAppConfig.value.share_url}?invite_code=from_id_${user.data.id}`,
				imageUrl: shareAppConfig.value.share_img,
				success: res => {
					//console.log(res);
				},
				fail: err => {
					//console.log(err);
				}
			})
		}
		
		// 如果是app分享到微信朋友圈
		if (item.type == 'app-time-line') {
			uni.share({
				provider:'weixin',
				type: 0, // 分享图文
				title: shareAppConfig.value.share_title,
				scene: 'WXSceneTimeline', // 分享到微信朋友圈
				summary: '',
				href: `${shareAppConfig.value.share_url}?invite_code=from_id_${user.data.id}`,
				imageUrl: shareAppConfig.value.share_img,
				success: res => {
					//console.log(res);
				},
				fail: err => {
					//console.log(err);
				}
			})
		}
	}
	
	// 暴露方法给父组件
	defineExpose({
		changeShow,
	})
	
	// 共享样式
	defineOptions({
		options: { 
			styleIsolation: 'shared',
		}
	});
</script>

<style lang="scss" scoped>
	/*  #ifdef H5  */
	.share-list{box-sizing: border-box;padding:0rpx 24rpx 20rpx 24rpx;}
	/*  #endif  */
	/*  #ifndef H5  */
	.share-list{box-sizing: border-box;padding:0rpx 24rpx 20rpx 24rpx;}
	/*  #endif  */
	.share-list .ms{box-sizing: border-box;padding:40rpx 24rpx 24rpx;background:#fff;border-radius: 24rpx;}
	.share-list .ms .m{display: flex;overflow-x: auto;}
	.share-list .ms .m .item{width:176rpx;display: flex;flex-direction: column;justify-content: center;align-items: center;flex:0 0 auto;position: relative;}
	.share-list .ms .m .item .wechat-share{width:100%;height:100%;z-index: 1;position: absolute;left:0px;top:0px;margin:0px;padding:0px;opacity: 0;}
	.share-list .ms .m .item .img{width:80rpx;height:80rpx;}
	.share-list .ms .m .item .title{}
	.share-list .ms .m .item .title .txt{font-size:28rpx;font-weight: 500;}
	.share-list .ms .b{margin:48rpx 24rpx 24rpx;}
	
	.wx-up-right-img{width:500rpx;height:470rpx;position: fixed;right:10px;top:10px;}
</style>
