<template>
	<view class="area-empty">
		<template v-if="status == 'nodata' || status == 'noLogin'">
			<wd-status-tip 
				:image="`${app.globalData.staticURL}${img}`"
				:image-size="imageSize"
				:tip="tip"
			/>
			<slot></slot>
		</template>
		<template v-if="status == 'loading'">
			<div class="loader-item">
				<div class="dual-ring"></div>
			</div>
		</template>
		<template v-if="status == 'noMore'">
			<wd-text
			  text="没有更多数据了"
			></wd-text>
		</template>
	</view>
</template>

<script setup>
	// 参考 https://wot-ui.cn/component/status-tip.html
	import { computed } from 'vue';
	const app = getApp();
	const props = defineProps({
		tip: {
			type: String,
			default: '暂无数据'
		},
		imageSize: {
			type: Number,
			default: 200
		},
		status: {
			type: String,
			default: '' // 数据状态  'loading' 'noMore' 'nodata' 'noLogin'
		},
		img: {
			type: String,
			default: '/nodata.png'
		}
	})
</script>

<style lang="scss" scoped>
	.area-empty{display:flex;align-items:center;justify-content:center;padding:20rpx 0rpx;flex-direction: column;}
	.loader-item{display:flex;flex-direction:column;align-items:center;}
	.loader-item .dual-ring{width:28px;height:28px;border:3px solid transparent;border-top:3px solid var(--superadminx-color);border-right:3px solid var(--superadminx-color);border-radius:50%;animation:spin 1s linear infinite}
	.loader-item .dual-ring:after{content:"";position:absolute;width:16px;height:16px;margin:3px;border:3px solid transparent;border-top:3px solid var(--superadminx-color-light2);border-right:3px solid var(--superadminx-color-light2);border-radius:50%;animation:spinReverse 0.6s linear infinite}
	        
	/* 动画定义 */
	@keyframes spin {
		0% { transform: rotate(0deg); }
		100% { transform: rotate(360deg); }
	}
	
	@keyframes spinReverse {
		0% { transform: rotate(0deg); }
		100% { transform: rotate(-360deg); }
	}
</style>
