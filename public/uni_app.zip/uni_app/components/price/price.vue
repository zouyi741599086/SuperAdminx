<template>
	<view style="display:inline-block;">
		<view 
			class="price-component"
			:class="{
				'price-component-medium': size == 'medium',
				'price-component-large': size == 'large',
				'price-component-white': white
			}"
			:style="`font-weight:${bold ? '600' : 'normal'}`"
		>
			<text class="prefix" v-if="prefix">{{prefix}}</text>
			<text class="integer">{{moneyShow(price, 1)}}</text>
			<text class="decimal">{{moneyShow(price, 2)}}</text>
			<text class="unit" v-if="unit">{{unit}}</text>					
			<text class="market-price" v-if="parseFloat(marketPrice) > 0">￥{{marketPrice}}</text>					
		</view>
	</view>
</template>

<script setup>
	// 商品列表
	import { ref} from 'vue';
	
	// 共享样式
	defineOptions({
		options: { 
			styleIsolation: 'shared',
		} ,
	});
	
	const app = getApp();
	const props = defineProps({
		// 价格
		price: {
			type: [Number, String],
			default: 0
		},
		// 是否显示前缀
		prefix: {
			type: String,
			default: '￥'
		},
		// 是否显示原价
		marketPrice: {
			type: [Number, String],
			default: null
		},
		// 是否显示单位
		unit: {
			type: [Number, String],
			default: null
		},
		// 大小 medium》中号，large》大号
		size: {
			type: String,
			default: ''
		},
		// 顔色是否用白色
		white: {
			type: Boolean,
			default: false
		},
		// 是否加粗
		bold: {
			type: Boolean,
			default: true
		}
	})
	
	/**
	 * 将金额拆分
	 * @param {string || float} money 金额
	 * @param {int} type 1》返回整数部分，2》返回小数点部分
	 */
	const moneyShow = (money, type = 1) => {
		// 处理空值情况
		const num = money == null || money === '' ? 0 : Number(money);
		const moneyStr = String(num);
		
		// 特殊处理整数和科学计数法
		if (/^[+-]?\d+$/.test(moneyStr)) {
			return type === 1 ? moneyStr : '';
		}
		
		const [integer, decimal] = moneyStr.split('.');
		
		switch (type) {
			case 1: return integer;
			case 2: return decimal ? `.${decimal}` : '';
		}
	}
</script>

<style lang="scss" scoped>
	.price-component{font-weight: 600;color: var(--superadminx-price-color);display: flex;flex:1;height:40rpx;line-height: 40rpx;overflow: hidden;}
	.price-component .prefix{font-size: 24rpx;line-height:46rpx;}
	.price-component .integer{font-size: 32rpx;}
	.price-component .decimal{font-size: 24rpx;line-height:46rpx;}
	.price-component .market-price{margin-left: 6rpx;font-size: 24rpx;font-weight: 400;color: #999999;text-decoration: line-through;line-height: 46rpx;}
	.price-component .unit{margin-left: 6rpx;font-size: 24rpx;font-weight: 400;color: #999999;line-height: 46rpx;}
	
	.price-component-large{line-height:56rpx;height:56rpx;}
	.price-component-large  .prefix{font-size:28rpx;line-height:68rpx;}
	.price-component-large  .integer{font-size:48rpx;}
	.price-component-large  .decimal{font-size:28rpx;line-height:68rpx;}
	.price-component-large  .market-price{font-size:28rpx;line-height:68rpx;}
	.price-component-large  .unit{font-size:28rpx;line-height:68rpx;}
	
	.price-component-medium{line-height:48rpx;height:48rpx;}
	.price-component-medium  .prefix{font-size:24rpx;line-height:58rpx;}
	.price-component-medium  .integer{font-size:40rpx;}
	.price-component-medium  .decimal{font-size:24rpx;line-height:58rpx;}
	.price-component-medium  .market-price{font-size:24rpx;line-height:58rpx;}
	.price-component-medium  .unit{font-size:24rpx;line-height:58rpx;}
	
	.price-component-white{color:#fff;}
	.price-component-white .market-price,
	.price-component-white .unit{color:#fff;}
	
</style>
