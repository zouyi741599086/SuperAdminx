<template>
	<wd-popup
		v-model="show" 
		position="bottom" 
		safe-area-inset-bottom
		custom-style="border-top-left-radius:36rpx;border-top-right-radius:36rpx;"
	>
		<view class="group-buy-rule" @click.stop="">
			<view class="title">
				<view class="t1">
					<text class="txt">{{title}}</text>
				</view>
				<text
					@click="changeShow()"
					class="tb-close"
				>&times;</text>
			</view>
			
			<scroll-view class="warp" scroll-y>
				<view class="area-rich-text">
					<mp-html :content="content" />
				</view>
			</scroll-view>
		</view>
	</wd-popup>
</template>

<script setup>
	// config配置里面的一些单页 协议等
	import { ref, computed, onMounted} from 'vue';
	
	const app = getApp();
	const props = defineProps({
		// 弹窗标题
		title: {
			type: String,
			default: ''
		},
		// 配置名称
		configName: {
			type: String,
			default: ''
		}
	})
	
	const show = ref(false); // 弹窗开关
	const content = ref(); // 内容
	
	// 共享样式
	defineOptions({
		options: { 
			styleIsolation: 'shared',
		} ,
	});
	
	// 获取内容
	const getConfig = () => {
		app.globalData.util.getConfig(props.configName).then(res => {
			content.value = res.content;
		})
	}
	
	// 弹窗开关
	function changeShow(){
		// 弹窗打开的时候在去请求数据
		if (show.value == false && ! content.value) {
			getConfig();
		}
		show.value = ! show.value;
	}
	
	// 暴露方法给父组件
	defineExpose({
		changeShow,
	})
</script>

<style lang="scss" scoped>
	.group-buy-rule{background-color: #ffffff;width: 100vw;box-sizing: border-box;z-index: 11;position: relative;}
	
	.group-buy-rule .title{padding:30rpx 24rpx;width:100%;box-sizing: border-box;}
	.group-buy-rule .title .t1{width:100%;box-sizing: border-box;padding-right:60rpx;}
	.group-buy-rule .title .t1 .txt{font-size:32rpx;font-weight: 600;}
	.group-buy-rule .tb-close{font-size: 50rpx;color: #999;position: absolute;right: 28rpx;top: 16rpx;font-weight: 500;}
	
	.group-buy-rule .warp{width:100%;min-height:500rpx;max-height:900rpx;overflow: hidden;box-sizing: border-box;}
	.group-buy-rule .warp .area-rich-text{overflow: hidden;box-sizing: border-box;padding:0px 24rpx 20rpx;}
</style>
