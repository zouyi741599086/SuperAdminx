<template>
	<wd-transition :show="true" name="fade">
		<view 
			class="area-swiper"
			:style="`padding: ${padding};border-radius:${borderRadius * 2}rpx;`"
		>
			<wd-skeleton
				:row-col="[
					[
					  { width: '100%', height: `${height * 2}rpx`},
					],
				]" 
				animation="gradient"
				:loading="bannerList.length == 0"
			>
				<swiper 
					class="r-swiper" 
					:style="`height:${height * 2}rpx;border-radius:${borderRadius * 2}rpx;`"
					autoplay 
					:interval="3000" 
					:indicator-dots="true" 
					indicator-color="rgba(255,255,255,0.5)"
					indicator-active-color="rgba(255,255,255,1)"
					:stop-propagation="false"
				>
					<swiper-item v-for="(item,index) in bannerList" :key="index">
						<view class="c-img">
							<image 
								:src="typeof item === 'string' ? item : item.img" 
								mode="aspectFill"
								class="img"
								:style="`border-radius:${borderRadius * 2}rpx;`"
								@click="clickAfter(item)"
							></image>
						</view>
					</swiper-item>
				</swiper>
			</wd-skeleton>
		</view>
	</wd-transition>
</template>

<script setup>
	// banner 轮播图 ，点击图片会跳转连接 或者 预览图片
	import { ref, watch, onMounted } from 'vue';
	import { configApi } from '@/utils/api/config.js';
	
	const app = getApp();
	const props = defineProps({
		// list 跟 name 传一个就可以了
		// 轮播图数据
		list: {
			type: Array,
			default: [] // ['xx/xx/1.jpg','xx/xx/xx.png'] 或者 [{img: 'xx/xx/x.png',url:''}]
		},
		// 获取轮播图配置的名称 获取轮播图数据
		name: {
			type: String,
			default: null
		},
		
		// 点击图片是跳转还是预览，toPages》跳转，preview》预览
		clickAction: {
			type: String,
			default: 'toPages'
		},
		
		// 轮播图高度，单位px
		height: {
			type: Number,
			default: 140
		},
		// 圆角，单位px
		borderRadius: {
			type: Number,
			default: 8
		},
		// 容器内边距
		padding: {
			type: String,
			default: '0rpx 24rpx'
		}
	})
	
	// 轮播图数据
	const bannerList = ref([]);
	
	// 获取数据
	const getData = () => {
		if (props.list?.length > 0) {
			bannerList.value = props.list;
			return;
		}
		
		if (props.name) {
			app.globalData.util.getConfig(props.name).then(res => {
				bannerList.value = res
			})
		}
	}
	
	// 暴露方法给父组件
	defineExpose({
		refresh: () => getData(),
	})
	
	// 监听参数变化
	watch(() => [props.list, props.name], () => {
		getData();
	}, { immediate: true, deep: true });
	
	// 点击图片的时候
	const clickAfter = (item) => {
		// 如果是跳转页面
		if (props.clickAction == 'toPages' && item.url) {
			app.globalData.toPages(item.url)
		}
		// 如果是预览图片
		if (props.clickAction == 'preview') {
			app.globalData.util.previewImg(item, bannerList.value);
		}
	}
	
</script>

<style lang="scss" scoped>
	.area-swiper{overflow: hidden;position: relative;}
	.area-swiper .r-swiper{width: 100%;overflow: hidden;}
	.area-swiper .r-swiper .c-img{width: 100%;height: 100%;}
	.area-swiper .r-swiper .c-img .img{width: 100%;height: 100%;display: block;}
</style>
