<template>
	<wd-transition :show="bannerData?.img ? true : false" name="fade">
		<view
			class="ad-banner"
			:style="{
				padding: padding
			}"
		>
			<image :src="bannerData.img" mode="widthFix" class="img" @click="toPages"></image>
		</view>
	</wd-transition>
</template>

<script setup>
	// 通栏广告
	import { ref, onMounted } from 'vue';
	const app = getApp();
	const props = defineProps({
		// 数据
		data: {
			type: Object,
			default: {
				img: '',
				url: ''
			}
		},
		// 不传数据则传配置的name，自动获取
		name: {
			type: String,
			default: ''
		},
		// 边距
		padding: {
			type: String,
			default: '10rpx 24rpx'
		}
	})
	
	const bannerData = ref({});
	
	onMounted(() => {
		if (props.name) {
			app.globalData.util.getConfig(props.name).then(res => {
				bannerData.value = res;
			})
		}
		if (props.data) {
			bannerData.value = props.data;
		}
	})
	
	function toPages(){
		if (props.data.url) {
			app.globalData.util.toPages(props.data.url)
		}
	}
	
</script>

<style lang="scss" scoped>
	.ad-banner{width:auto;border-radius: 32rpx;}
	.ad-banner .img{width:100%;border-radius: 32rpx;}
</style>
