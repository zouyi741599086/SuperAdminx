<template>
	<wd-popup 
		v-model="show" 
		position="bottom" 
		safe-area-inset-bottom
		:z-index="9" 
		custom-style="border-top-left-radius:36rpx;border-top-right-radius:36rpx;"
		@close="close"
	>
		<view class="popup-box" @click.stop="">
			<view class="title">
				<text class="txt">支付方式</text>
			</view>
			
			<view class="warp">
				<template v-for="(item,index) in getPayType" :key="index">
					<view 
						class="item"
						hover-class="item-on"
						@click="pay(item.value)"
					>
						<view class="icon">
							<image
								:src="`${app.globalData.staticURL}${item.icon}`" 
								class="c-tb" 
							></image>
						</view>
						<view class="l">
							<text class="txt">{{item.name}}</text>
							<text class="money" v-if="item.value == 'money'">
								({{balance.data.money}})
							</text>
						</view>
						<view class="r">
							<wd-icon 
								name="chevron-right" 
								size="22px"
								color="#999"
							></wd-icon>
						</view>
					</view>
				</template>
			</view>
			<view class="close" @click="changeShow();">取消</view>
		</view>
	</wd-popup>
</template>

<script setup>
	/**
	 * 支付弹窗
	 * 内部已处理各个端(如微信小程序不能用支付宝)能发起的支付
	 * 如果只有一种支付方式会直接调起支付，不会弹窗
	 */
	import { ref, computed, onMounted} from 'vue';
	import { useBalanceStore } from '@/store/balance.js';
	import { useSubmit } from '@/utils/useSubmit.js';
	// #ifdef H5
	import wx from 'weixin-js-sdk';
	// #endif
	
	const props = defineProps({
		// 获取支付参数的api
		api: {
			type: Function,
			required: true
		},
		// 请求支付参数时携带的参数
		params: {
			type: Object,
			default: {}
		},
		// 可使用的支付
		payType: {
			type: Array,
			default: ['money', 'wechat', 'alipay']
		},
		// 支付成功后执行的函数，立即调用，自行处理是否需要延时
		paySuccess: {
			type: Function,
			default: () => {}
		},
		// 支付失败或取消支付后执行的函数，立即调用，自行处理是否需要延时
		payError: {
			type: Function,
			default: () => {}
		}
	})
	
	const app = getApp();
	const balance = useBalanceStore(); // 余额信息
	const show = ref(false); // 弹窗开关
	const { submitting, handleSubmit } = useSubmit(true); // 表单提交钩子
	
	onMounted(()=>{
		
	})
	
	// 获取支付方式
	const getPayType = computed(() => {
		// 支付方式
		const list = [
			{name: '余额支付', value: 'money', icon: '/balance.png'},
			{name: '微信支付', value: 'wechat', icon: '/wx.png'},
			// #ifndef MP-WEIXIN
			{name: '支付宝支付', value: 'alipay', icon: '/zfb.png'},
			// #endif
		];
		return list.filter(item => props.payType.includes(item.value));
	})
	
	// 弹窗关闭的时候
	const close = () => {
		app.globalData.util.toast('取消支付');
		props.payError();
	}
	
	// 弹窗开关
	const changeShow = () => {
		// 如果是开启弹窗的时候，只有一种支付方式的话，直接调起支付
		if (! show.value && getPayType.value.length == 1) {
			return pay(getPayType.value[0].value);
		}
		
		show.value = ! show.value;
		if (show.value == false) {
			close();
		}
	}
	
	// 暴露方法给父组件
	defineExpose({
		changeShow,
	})
	
	// 支付
	const pay = (payType) => {
		switch (payType) {
			case 'money':
				moneyPay();
				break;
			case 'wechat':
				wechatPay();
				break;
			case 'alipay':
				alipay();
				break;
		}
	}
	
	// 余额支付
	const moneyPay = () => {
		app.globalData.util.modal('确定使用余额支付吗？').then(() => {
			handleSubmit(() => {
				return props.api({
					...props.params,
					pay_type: 'money',
					pay_source: getPaySource()
				},true).then(res => {
					paySuccessAfter(res.message);
					return res;
				}).catch(res => {
					payErrorAfter();
				})
			})
		})
	}
	
	// 微信支付
	const wechatPay = () => {
		handleSubmit(() => {
			const pay_source = getPaySource();
			return props.api({
				...props.params,
				pay_type: 'wechat',
				pay_source: pay_source,
			},true).then( payResult => {
				// h5支付
				if (pay_source == 'h5') {
					location.href = payResult.data;
				} 
				
				// 公众号支付
				if (pay_source == 'mp') {
					wx.chooseWXPay({
						appId: payResult.data.appId,
						timestamp: payResult.data.timeStamp, 
						nonceStr: payResult.data.nonceStr, 
						package: payResult.data.package, 
						signType: payResult.data.signType,
						paySign: payResult.data.paySign, 
						success: function(res) {
							if(res.errMsg == "chooseWXPay:ok" ) {
								paySuccessAfter('支付成功');
							}else{
								payErrorAfter('支付失败');
							}
						},
						cancel: function(res) {
							payErrorAfter('取消支付');
						},
						fail: function(res) {
							payErrorAfter('支付失败');
						}
					});
				}
				
				// app 或 小程序支付
				if (pay_source == 'app' || pay_source == 'mini') {
					uni.requestPayment({
						provider: "wxpay",  //固定值为"wxpay"
						orderInfo: payResult.data, 
						...payResult.data, // 微信小程序才这样
						success: res => {
							paySuccessAfter('支付成功');
						},
						fail: err => {
							payErrorAfter('支付失败');
						}
					});
				}
				return payResult;
			}).catch(res => {
				payErrorAfter();
			})
		})
	}
	
	// 支付宝支付
	const alipay = () => {
		handleSubmit(() => {
			const pay_source = getPaySource();
			return props.api({
				...props.params,
				pay_type: 'alipay',
				pay_source: pay_source
			},true).then( payResult => {
				// h5支付
				if (pay_source == 'h5') {
					window.location.href = payResult.data;
				} 
				
				// app支付
				if (pay_source == 'app'){
					uni.requestPayment({
						provider: "alipay",  //固定值为"alipay"
						orderInfo: payResult.data, 
						success: res => {
							paySuccessAfter('支付成功');
						},
						fail: err => {
							payErrorAfter('支付失败');
						}
					});
				}
				return payResult;
			}).catch(res => {
				payErrorAfter();
			})
		})
	}
	
	// 获取支付源
	const getPaySource = () => {
		// 微信浏览器内则是公众号支付
		if (app.globalData.util.isWeChatBrowser()) {
			return 'mp';
		}
	
		// #ifdef WEB || H5
		return 'h5';
		// #endif
		
		// #ifdef APP
		return 'app';
		// #endif
		
		// #ifdef MP-WEIXIN
		return 'mini';
		// #endif
	}
	
	// 支付成功
	const paySuccessAfter = (message = null) => {
		if (message) {
			app.globalData.util.toast(message);
		}
		show.value = false;
		props.paySuccess();
	}
	
	// 支付失败
	const payErrorAfter = (message = null) => {
		if (message) {
			app.globalData.util.toast(message);
		}
		show.value = false;
		props.payError();
	}
</script>

<style lang="scss" scoped>
	.popup-box{background-color: #ffffff;width: 100vw;box-sizing: border-box;z-index: 11;}
	
	.popup-box .title{text-align: center;padding: 30rpx 0rpx;}
	.popup-box .title .txt{font-size:32rpx;font-weight: 600;}
	.popup-box .warp{width:100%;padding:20rpx 0rpx;box-sizing: border-box;}
	.popup-box .warp .item{display: flex;width:100%;overflow: hidden;padding:26rpx 24rpx;box-sizing: border-box;}
	.popup-box .warp .item-on{background-color: #f9f9f9;}
	.popup-box .warp .item .icon .c-tb{width:40rpx;height:40rpx;}
	.popup-box .warp .item .l{flex:1;padding-left:20rpx;}
	.popup-box .warp .item .l .txt{font-size:30rpx;font-weight: 600;}
	.popup-box .warp .item .l .money{font-size:28rpx;font-weight: normal;color:#666;}
	.popup-box .close{width:auto;margin:24rpx;background: #f5f5f5;text-align: center;line-height:80rpx;color:#666;font-size:28rpx;border-radius: 100rpx;font-weight: 500;}
</style>
